import sys,time,json,itertools
from pysat.solvers import Solver
from pysat.formula import IDPool
from pysat.card import CardEnc,EncType
n=8;k=int(sys.argv[1]);haszero=int(sys.argv[2]);start=time.time();pool=IDPool();solver=Solver(name='cadical195')
p=lambda x,y,z:pool.id(('p',x,y,z));sq=lambda z:pool.id(('s',z));col=lambda x,a:pool.id(('col',x,a));left=lambda x,b:pool.id(('left',x,b));path=lambda z,u,v:pool.id(('path',z,u,v))
for x,y in itertools.product(range(n),repeat=2):
 for c in CardEnc.equals([p(x,y,z)for z in range(n)],1,vpool=pool,encoding=EncType.seqcounter):solver.add_clause(c)
for z,s in itertools.product(range(n),repeat=2):solver.add_clause([-p(z,z,s),sq(s)])
for s in range(n):solver.add_clause([-sq(s)]+[p(z,z,s)for z in range(n)])
for x,s,b in itertools.product(range(n),repeat=3):solver.add_clause([-sq(s),-p(x,s,b),left(x,b)])
for x,y,a in itertools.product(range(n),repeat=3):solver.add_clause([-p(y,x,a),col(x,a)])
for x,a,b in itertools.product(range(n),repeat=3):solver.add_clause([-left(x,b),-col(x,a),p(a,b,x)])
# The diagonal map is tripotent.
for x,s,t in itertools.product(range(n),repeat=3):solver.add_clause([-p(x,x,s),-p(s,s,t),p(t,t,s)])
# Out-neighborhoods of distinct out-neighbors are disjoint.
for z,u,v,w in itertools.product(range(n),repeat=4):
 if u<v:solver.add_clause([-left(z,u),-left(z,v),-left(u,w),-left(v,w)])
# Every square is reached by a two-step path from each vertex.
for z,u,v in itertools.product(range(n),repeat=3):
 q=path(z,u,v);a=left(z,u);b=left(u,v)
 solver.add_clause([-q,a]);solver.add_clause([-q,b]);solver.add_clause([q,-a,-b])
for z,s in itertools.product(range(n),repeat=2):solver.add_clause([-sq(s)]+[path(z,u,s)for u in range(n)])
# Relabel a vertex with smallest square-row rank as zero.
for x in range(n):
 for c in CardEnc.atleast([left(x,b)for b in range(n)],k,vpool=pool,encoding=EncType.seqcounter):solver.add_clause(c)
for b in range(n):
 target=set(range(k))if haszero else set(range(1,k+1))
 solver.add_clause([left(0,b)if b in target else-left(0,b)])
print(k,haszero,'encoded',pool.top,solver.nof_clauses(),'seconds',time.time()-start,flush=True)
status=solver.solve();print(k,haszero,status,time.time()-start,flush=True)
if status:
 m=set(solver.get_model());t=[[next(z for z in range(n)if p(x,y,z)in m)for y in range(n)]for x in range(n)]
 assert all(t[t[y][x]][t[x][t[z][z]]]==x for x,y,z in itertools.product(range(n),repeat=3))
 json.dump({'order':n,'table':t},open(f'/tmp/e1486-eight-20260926/model-{k}-{haszero}.json','w'))
