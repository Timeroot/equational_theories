fof(e,axiom, ![X,Y,Z]: f(f(Y,X),f(X,f(Z,Z)))=X).
fof(single,axiom, ![Z]: f(a,f(Z,Z))=b).
fof(goal,conjecture, ![X,Y]: X=Y).
