from pathlib import Path
import sys
sys.path.insert(0,'scripts');import spectrum_small_certificates as c
R=Path('equational_theories/Spectrum/Equation1486')
enc='\n'.join(['import equational_theories.Spectrum.Basic','import equational_theories.Spectrum.Status','import Lean.Elab.Tactic.BVDecide','import Mathlib.Tactic.FinCases','import Mathlib.Data.Fin.VecNotation','','namespace Spectrum.FiniteTableEncoding',c.encoding(8),'end Spectrum.FiniteTableEncoding',''])
(R/'Encoding8.lean').write_text(enc)
s=c.raw_certificate(1486,8,120)
s=s.replace('import equational_theories.Spectrum.FiniteTableEncoding','import equational_theories.Spectrum.Equation1486.Encoding8')
s=s[:s.index('theorem Spectrum.not_order_1486_8')]
s=s.replace('E1486N8','E1486N8TwoImages')
args=' '.join(f'a{i}'for i in range(8)); rows=' '.join(f'(rows M {i})'for i in range(8))
s=s.replace(f'def test ({args}',f'def test (inside : Bool) ({args}')
tests=[f'(op {args} 0 (op {args} {z} {z}) = (if inside then 0 else 1) ∨ op {args} 0 (op {args} {z} {z}) = (if inside then 1 else 2))'for z in range(8)]
s=s.replace(' : Prop :=\n  ',' : Prop :=\n  '+' ∧\n  '.join(tests)+' ∧\n  ',1)
s=s.replace(f'theorem refute ({args}',f'theorem refute (inside : Bool) ({args}').replace(f'¬ test {args}',f'¬ test inside {args}')
s=s.replace('  unfold test op clip\n  bv_decide','  cases inside <;> unfold test op clip <;>\n    bv_decide')
s=s.replace('theorem impossible (M :','theorem impossible (inside : Bool) (M :')
s=s.replace('(h : @Equation1486 (Fin 8) M) : False := by','(h : @Equation1486 (Fin 8) M)\n    (hi : ∀ z, M.op 0 (M.op z z) = (if inside then 0 else 1) ∨\n      M.op 0 (M.op z z) = (if inside then 1 else 2)) : False := by')
s=s.replace(f'  apply refute {rows}',f'  apply refute inside {rows}')
s=s.replace('  refine ⟨','  refine ⟨'+', '.join('?_'for _ in range(8))+', ',1)
pos=s.index('  · change');proof=''
for z in range(8):
 proof+=f'''  · change encoded M (bv (0 : Fin 8)) (encoded M (bv ({z} : Fin 8)) (bv ({z} : Fin 8))) = (if inside then 0 else 1) ∨
      encoded M (bv (0 : Fin 8)) (encoded M (bv ({z} : Fin 8)) (bv ({z} : Fin 8))) = (if inside then 1 else 2)
    simp only [he]
    have h0 := hi {z}
    cases inside <;> simpa [FiniteTableEncoding.N8.bv] using h0.elim (fun h => Or.inl (congrArg bv h)) (fun h => Or.inr (congrArg bv h))
'''
s=s[:pos]+proof+s[pos:]
(R/'EightRefutation.lean').write_text(s)
