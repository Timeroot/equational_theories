import json,itertools,numpy as np
models=[]
for path in ['data/definability_1483_rank_idempotent_counterexample.json','/tmp/e1483-focus-20260926/order8-rank2-90s.json','data/definability_1483_rank_search.json','/tmp/e1483-uniform-rank-20260926/counter-8-retraction-bNone-tNone.json']:
 j=json.load(open(path));m=j.get('table',j.get('positive_control',{}).get('table'));models.extend([np.array(m,dtype=np.uint8),np.array(m,dtype=np.uint8).T])
contexts=[]
for m in models:
 for e,a,b in itertools.product(range(len(m)),repeat=3):
  if a in m[e]and b in m[a]:
   t=int(m[e,b])
   for y in set(m[t]):contexts.append((m,e,a,b,t,int(y)))
mi=np.stack([c[0]if len(c[0])==9 else np.pad(c[0],((0,1),(0,1)))for c in contexts]);ix=np.arange(len(contexts))
vs={s:np.array([q[i+1]for q in contexts],dtype=np.uint8)for i,s in enumerate('eabty')}
def op(x,y):return mi[ix,x,y]
terms={};bysize={1:[]}
for k,v in vs.items():terms[v.tobytes()]=(k,v);bysize[1].append((k,v))
found=[]
for size in range(1,5):
 if size>1:
  bysize[size]=[]
  for i in range(1,size):
   for (x,xv),(y,yv) in itertools.product(bysize[i],bysize[size-i]):
    v=op(xv,yv);key=v.tobytes()
    if key in terms:continue
    name=f'({x}*{y})';terms[key]=(name,v);bysize[size].append((name,v))
 for name,v in bysize[size]:
  h=op(vs['a'],v);gh=op(vs['t'],op(h,vs['a']))
  if np.array_equal(gh,vs['y']):found.append(f'(a*{name})')
 print('contexts',len(contexts),'size',size,'new',len(bysize[size]),'total',len(terms),'inverse',found[:10],flush=True)
 if found:break
