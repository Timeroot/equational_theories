fof(law,axiom, ![X,Y,Z]:m(m(Y,X),m(X,m(Z,Y)))=X).
fof(dual,axiom, ![X,Y,Z]:m(m(m(Y,Z),X),m(X,Y))=X).
fof(a_def,axiom,a=m(e,z)).
fof(b_def,axiom,b=m(a,w)).
fof(t_def,axiom,t=m(e,b)).
fof(y_def,axiom,y=m(t,s)).
fof(goal,conjecture,m(t,m(m(a,m(y,t)),a))=y).
