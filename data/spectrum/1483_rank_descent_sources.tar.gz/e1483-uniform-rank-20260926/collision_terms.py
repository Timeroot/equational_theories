import json,itertools,numpy as np
models=[]
for path in ['data/definability_1483_rank_idempotent_counterexample.json','/tmp/e1483-focus-20260926/order8-rank2-90s.json']:
 m=json.load(open(path))['table'];models.extend([np.array(m),np.array(m).T])
contexts=[]
for m in models:
 for e,a,b in itertools.product(range(len(m)),repeat=3):
  if a in m[e]and b in m[a]and m[e,b]!=a:contexts.append((m,e,a,b,int(m[e,b])))
vs={s:np.array([q[i+1]for q in contexts])for i,s in enumerate('eabt')}
def op(x,y):return np.array([c[0][x[i],y[i]]for i,c in enumerate(contexts)])
terms=dict(vs)
for x,y in itertools.product(vs,repeat=2):terms[f'({x}*{y})']=op(vs[x],vs[y])
orig=dict(terms)
for x,y in itertools.product(orig,repeat=2):
 if x not in vs and y not in vs:continue
 terms[f'({x}*{y})']=op(orig[x],orig[y])
domain={'b':vs['b']}
for q,v in terms.items():domain[f'(a*{q})']=op(vs['a'],v)
groups={}
for q,v in domain.items():
 image=op(vs['t'],op(v,vs['a']));groups.setdefault(tuple(image),[]).append((q,v))
found=[]
for bucket in groups.values():
 for (p,u),(q,v) in itertools.combinations(bucket,2):
  if np.all(u!=v):found.append((len(p)+len(q),p,q))
print('contexts',len(contexts),'terms',len(domain),'collisiongroups',len(groups));print(sorted(found)[:30])
