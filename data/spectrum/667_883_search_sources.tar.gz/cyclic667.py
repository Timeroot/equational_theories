from pysat.solvers import Solver
from pysat.card import CardEnc,EncType
import sys,itertools,json,time
n=int(sys.argv[1]);budget=int(sys.argv[2]);cc=int(sys.argv[3])
s=Solver(name='cadical195')
def v(x,y):return 1+(x%n)*n+y%n
top=n*n
vslist=[[v(x,y)for y in range(n)]for x in range(n)]+[[v(x,y)for x in range(n)]for y in range(n)]+[[v(x,x+y)for x in range(n)]for y in range(n)]
for vs in vslist:
 e=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=e.nv;s.append_formula(e.clauses)
s.add_clause([v(0,cc)])
# f(f(c+f(d-c))-d)=-d
for d,a,b in itertools.product(range(n),repeat=3):s.add_clause([-v(d-cc,a),-v(cc+a,b),v(b-d,-d)])
t=time.monotonic();s.conf_budget(budget);r=s.solve_limited();o={'law':667,'order':n,'cyclic_diagonal_shift':cc,'result':r,'seconds':time.monotonic()-t}
if r:
 m=set(s.get_model());f=[next(y for y in range(n)if v(x,y)in m)for x in range(n)];o['f']=f
 def op(x,y):return (x+f[(y-x)%n])%n
 assert all(op(y,op(x,op(op(x,x),y)))==x for x in range(n)for y in range(n))
print(json.dumps(o),flush=True);open(f'/tmp/e667883-20260926/cyclic667-{n}-{cc}.json','w').write(json.dumps(o,indent=2))
