import itertools,json,sys,time
from pathlib import Path
from pysat.solvers import Solver
from pysat.card import CardEnc,EncType
n,shift,budget=map(int,sys.argv[1:4]);start=time.monotonic()
s=Solver(name='cadical195')
def v(x,y,z):return 1+x*n*n+y*n+z
top=n**3
for x,y in itertools.product(range(n),repeat=2):
 for vs in ([v(x,y,z) for z in range(n)],[v(x,z,y) for z in range(n)],[v(z,x,y) for z in range(n)]):
  e=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=e.nv;s.append_formula(e.clauses)
for x,y,z in itertools.product(range(n),repeat=3):
 s.add_clause([-v(x,y,z),v((x+shift)%n,(y+shift)%n,(z+shift)%n)])
for x,y,d,u,w in itertools.product(range(n),repeat=5):
 s.add_clause([-v(x,x,d),-v(d,y,u),-v(x,u,w),v(y,w,x)])
s.conf_budget(budget);r=s.solve_limited()
out={'law':667,'order':n,'automorphism_shift':shift,'restriction':'op(x+s,y+s)=op(x,y)+s modulo n','conflict_budget':budget,'status':'SAT' if r else 'UNSAT' if r is False else 'UNKNOWN','seconds':time.monotonic()-start}
if r:
 model=set(s.get_model());a=[next(z for z in range(n)if v(x,y,z)in model)for x,y in itertools.product(range(n),repeat=2)]
 sys.path.insert(0,'scripts');from spectrum_generate import load_equations,satisfies
 assert satisfies(*load_equations()[666],a,n)
 out['table']=a
path=Path(f'/tmp/e667883-20260926/automorphism667-{n}-{shift}.json');path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
