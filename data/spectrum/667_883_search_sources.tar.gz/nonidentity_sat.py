import itertools,json,time,sys
from pathlib import Path
from pysat.solvers import Solver
from pysat.card import CardEnc,EncType
law,n,budget=map(int,sys.argv[1:4]);restriction=sys.argv[4] if len(sys.argv)>4 else 'any'
s=Solver(name='cadical195')
def v(x,y,z):return 1+x*n*n+y*n+z
top=n**3
for x,y in itertools.product(range(n),repeat=2):
 for vs in ([v(x,y,z) for z in range(n)],[v(x,z,y) for z in range(n)],[v(z,x,y) for z in range(n)]):
  e=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=e.nv;s.append_formula(e.clauses)
s.add_clause([v(0,0,0),v(0,0,1)])
if restriction=='constant':
 for x in range(n):s.add_clause([v(x,x,0)])
if restriction=='idem':
 for x in range(n):s.add_clause([v(x,x,x)])
for x,y,d,u,w in itertools.product(range(n),repeat=5):
 if law==667:s.add_clause([-v(x,x,d),-v(d,y,u),-v(x,u,w),v(y,w,x)])
 else:s.add_clause([-v(y,y,d),-v(x,y,u),-v(u,d,w),v(y,w,x)])
s.add_clause([-v(0,j,j) for j in range(n)])
start=time.monotonic();print('start',law,n,restriction,flush=True);s.conf_budget(budget);r=s.solve_limited()
out={'law':law,'order':n,'restriction':restriction,'status':'SAT' if r else 'UNSAT' if r is False else 'UNKNOWN','seconds':time.monotonic()-start,'conflicts':s.accum_stats().get('conflicts')}
if r:
 model=set(s.get_model());a=[next(z for z in range(n) if v(x,y,z) in model) for x,y in itertools.product(range(n),repeat=2)]
 sys.path.insert(0,'scripts');from spectrum_generate import load_equations,satisfies
 assert satisfies(*load_equations()[law-1],a,n)
 out['table']=a;out['diagonal']=[a[x*n+x]for x in range(n)]
Path(f'/tmp/e667883-20260926/{law}-{n}-{restriction}-nonidentity-row-sat.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
s.delete()
