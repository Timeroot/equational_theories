import itertools,json,time,sys
from pathlib import Path
from pysat.solvers import Solver
from pysat.card import CardEnc,EncType
law,n,budget=map(int,sys.argv[1:4]);restriction=sys.argv[4] if len(sys.argv)>4 else 'any'
s=Solver(name='cadical195')
def v(x,y,z):return 1+x*n*n+y*n+z
top=n**3
for x,y in itertools.product(range(n),repeat=2):
 for vs in ([v(x,y,z) for z in range(n)],[v(x,z,y) for z in range(n)],[v(z,x,y) for z in range(n)]):
  e=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=e.nv;s.append_formula(e.clauses)
s.add_clause([v(0,0,0),v(0,0,1)])
if restriction=='constant':
 for x in range(n):s.add_clause([v(x,x,0)])
if restriction=='idem':
 for x in range(n):s.add_clause([v(x,x,x)])
for x,y,d,u,w in itertools.product(range(n),repeat=5):
 if law==667:s.add_clause([-v(x,x,d),-v(d,y,u),-v(x,u,w),v(y,w,x)])
 else:s.add_clause([-v(y,y,d),-v(x,y,u),-v(u,d,w),v(y,w,x)])

def partitions(n, cap=None):
 if n==0:
  yield []
  return
 for a in range(min(n,n if cap is None else cap),0,-1):
  for tail in partitions(n-a,a):yield [a]+tail
previous=json.loads(Path(f'/tmp/e667883-20260926/{law}-{n}-rowcycles.json').read_text());wanted={(c['zero_cycle'],tuple(c['other_cycles'])) for c in previous['cases']if c['status']=='UNKNOWN'}
start=time.monotonic();out=[]
for k in range(1,n+1):
 for tail in partitions(n-k):
  if (k,tuple(tail))not in wanted:continue
  pi=list(range(n));p=0
  for length in [k]+tail:
   for j in range(length):pi[p+j]=p+(j+1)%length
   p+=length
  s.conf_budget(budget)
  result=s.solve_limited(assumptions=[v(0,j,pi[j]) for j in range(n)])
  row={'zero_cycle':k,'other_cycles':tail,'status':'SAT' if result else 'UNSAT' if result is False else 'UNKNOWN'}
  if result:
   model=set(s.get_model());a=[next(z for z in range(n) if v(x,y,z) in model) for x,y in itertools.product(range(n),repeat=2)]
   sys.path.insert(0,'scripts');from spectrum_generate import load_equations,satisfies
   assert satisfies(*load_equations()[law-1],a,n)
   row['table']=a
  out.append(row);print(json.dumps(row),flush=True)
  if result:break
 if result:break
Path(f'/tmp/e667883-20260926/{law}-{n}-rowcycles-refined.json').write_text(json.dumps({'law':law,'order':n,'conflict_budget_per_case':budget,'seconds':time.monotonic()-start,'cases':out},indent=2)+'\n')
print('done',len(out),'seconds',time.monotonic()-start,flush=True)
