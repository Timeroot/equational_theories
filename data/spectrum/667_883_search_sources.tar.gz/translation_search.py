from pysat.solvers import Solver
from pysat.card import CardEnc,EncType
import sys,itertools,json,time
kind,n,budget,cc=sys.argv[1],*map(int,sys.argv[2:5])
s=Solver(name='cadical195')
if kind=='binary':
 add=lambda x,y:3*((x//3)^(y//3))+(x%3+y%3)%3
 neg=lambda x:3*(x//3)+(-x%3)%3
else:
 add=lambda x,y:(x+y)%n
 neg=lambda x:-x%n
sub=lambda x,y:add(x,neg(y))
def v(x,y):return 1+x*n+y
top=n*n
vslist=[[v(x,y)for y in range(n)]for x in range(n)]+[[v(x,y)for x in range(n)]for y in range(n)]+[[v(x,add(x,y))for x in range(n)]for y in range(n)]
for vs in vslist:
 e=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=e.nv;s.append_formula(e.clauses)
s.add_clause([v(0,cc)])
for d,a,b in itertools.product(range(n),repeat=3):s.add_clause([-v(sub(d,cc),a),-v(add(cc,a),b),v(sub(b,d),neg(d))])
t=time.monotonic();s.conf_budget(budget);r=s.solve_limited();o={'law':667,'order':n,'group':kind,'shift':cc,'result':r,'seconds':time.monotonic()-t}
if r:
 m=set(s.get_model());f=[next(y for y in range(n)if v(x,y)in m)for x in range(n)];o['f']=f
 def op(x,y):return add(x,f[sub(y,x)])
 assert all(op(y,op(x,op(op(x,x),y)))==x for x in range(n)for y in range(n))
 o['table']=[op(x,y) for x in range(n)for y in range(n)]
print(json.dumps(o),flush=True);open(f'/tmp/e667883-20260926/translate667-{kind}-{n}-{cc}.json','w').write(json.dumps(o,indent=2))
