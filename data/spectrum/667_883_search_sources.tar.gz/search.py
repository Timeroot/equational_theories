import sys,json,time,z3,itertools
from pathlib import Path
ROOT=Path('/home/alex_harmonic_fun/equational_theories');sys.path.insert(0,str(ROOT/'scripts'))
from spectrum_generate import load_equations,satisfies
law,n,seconds=map(int,sys.argv[1:4]);mode=sys.argv[4] if len(sys.argv)>4 else 'any'
c,els=z3.EnumSort('C'+str(n),['e'+str(n)+'_'+str(i) for i in range(n)])
f=z3.Function('f',c,c,c);s=z3.Solver();s.set(timeout=seconds*1000)
for y in els:
 s.add(z3.Distinct([f(x,y) for x in els]));s.add(z3.Distinct([f(y,x) for x in els]))
for x,y in itertools.product(els,repeat=2):
 rhs=f(y,f(x,f(f(x,x),y))) if law==667 else f(y,f(f(x,y),f(y,y)))
 s.add(rhs==x)
s.add(z3.Or(f(els[0],els[0])==els[0],f(els[0],els[0])==els[1]))
if mode=='notendo':
 x,y=els[:2];s.add(f(f(x,y),f(x,y))!=f(f(x,x),f(y,y)))
if mode=='constant':
 for x in els:s.add(f(x,x)==els[0])
if mode=='idem':
 for x in els:s.add(f(x,x)==x)
t=time.monotonic();status=s.check();out={'law':law,'order':n,'restriction':mode,'status':str(status),'seconds':time.monotonic()-t}
if status==z3.sat:
 idx={str(x):i for i,x in enumerate(els)}
 a=[idx[str(s.model().eval(f(x,y)))] for x,y in itertools.product(els,repeat=2)]
 assert satisfies(*load_equations()[law-1],a,n)
 out['table']=a;out['diagonal']=[a[i*n+i] for i in range(n)]
print(json.dumps(out),flush=True)
Path(f'/tmp/e667883-20260926/{law}-{n}-{mode}.json').write_text(json.dumps(out,indent=2)+'\n')
