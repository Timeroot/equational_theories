Exploratory E667/E883 searches, 26 September 2026.
These are archived research scripts, not inputs to any Lean proof.
They require python-sat; search.py also requires z3-solver. Run from the
repository root. Some paths deliberately retain the original scratch location
/tmp/e667883-20260926; create that directory before replaying.
The archived scripts document the exact encodings used for the bounded results
in data/spectrum/667_883_research.json. Timeouts and conflict-budget exhaustion
are inconclusive. Restricted-family UNSAT does not exclude arbitrary models.
The maintained reproducible E883 order-nine complete refutation is instead
scripts/spectrum_883_nine_search.py.
