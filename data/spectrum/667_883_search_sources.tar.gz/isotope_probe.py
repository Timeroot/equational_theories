import json,itertools,sys
from pathlib import Path
w=json.load(open('data/spectrum/witnesses.json'))

def holds(a,n,law):
 f=lambda x,y:a[x*n+y]
 return all((f(y,f(x,f(f(x,x),y))) if law==667 else f(y,f(f(x,y),f(y,y))))==x for x in range(n) for y in range(n))
for k in ['481:9','481:12','481:15']:
 a=w[k];n=int(k.split(':')[1]);e=a[0]
 assert all(a[i*n+i]==e for i in range(n))
 lp=[a[e*n+x]for x in range(n)];rp=[a[x*n+e]for x in range(n)]
 perms={0:list(range(n))}
 for z in range(1,2*n+1):
  p=[lp[x]for x in perms[z-1]]
  if p==perms[0]:break
  perms[z]=p
 print(k,'unit period',len(perms),flush=True)
 par=[a,[a[y*n+x]for x in range(n)for y in range(n)],[a[x*n:(x+1)*n].index(y)for x in range(n)for y in range(n)],[next(z for z in range(n)if a[z*n+y]==x)for x in range(n)for y in range(n)]]
 par +=[[b[y*n+x]for x in range(n)for y in range(n)]for b in par[2:]]
 for law in [667,883]:
  found=False
  for ip,b in enumerate(par):
   for u,v,z in itertools.product(perms,repeat=3):
    c=[perms[z][b[perms[u][x]*n+perms[v][y]]]for x in range(n)for y in range(n)]
    if holds(c,n,law):
     out={'law':law,'order':n,'source':k,'parastrophe':ip,'isotope':[u,v,z],'table':c}
     Path(f'/tmp/e667883-20260926/{law}-{n}-isotope.json').write_text(json.dumps(out,indent=2));print('FOUND',law,ip,u,v,z,flush=True);found=True;break
   if found:break
  if not found:print('none',law,flush=True)
