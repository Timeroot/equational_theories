import itertools,time,json,pathlib,random
P=pathlib.Path(__file__).resolve().parent

def nand3():
 def rot(x):return ((x<<1)|(x>>2))&7
 return [[7^(rot(x)&rot(rot(y))) for y in range(8)] for x in range(8)]
def central(q):return [[(x%q)*q+y//q for y in range(q*q)] for x in range(q*q)]
def product(A,B):
 n,m=len(A),len(B)
 return [[A[x//m][y//m]*m+B[x%m][y%m] for y in range(n*m)] for x in range(n*m)]
def closure(T,gens):
 n=len(T);mask=0;xs=[]
 for x in gens:
  if not(mask>>x&1):mask|=1<<x;xs.append(x)
 i=0
 while i<len(xs):
  a=xs[i];j=0
  while j<=i:
   b=xs[j]
   for c in (T[a][b],T[b][a]):
    if not(mask>>c&1):mask|=1<<c;xs.append(c)
   j+=1
  i+=1
 return mask

def sizesub(mask):return mask.bit_count()
def allowed(n):return any(n==r*r or n==2*r*r for r in range(1,n+1))
def run(name,T,seconds,limit):
 start=time.monotonic();N=len(T);seen={0};queue=[0];i=0;counts={};witnesses={};calls=0
 while i<len(queue) and time.monotonic()-start<seconds and len(seen)<limit:
  mask=queue[i];i+=1;gs=[a for a in range(N) if mask>>a&1]
  for a in range(N):
   if mask>>a&1:continue
   C=closure(T,gs+[a]);calls+=1
   if C in seen:continue
   seen.add(C);queue.append(C);n=C.bit_count();counts[n]=counts.get(n,0)+1
   if not allowed(n):
    xs=[j for j in range(N) if C>>j&1];idx={x:j for j,x in enumerate(xs)}
    M=[[idx[T[x][y]] for y in xs] for x in xs]
    assert all(M[M[y][x]][M[x][M[y][z]]]==x for x,y,z in itertools.product(range(n),repeat=3))
    witnesses[n]={'carrier':xs,'table':M}
    print('NEW SIZE',name,n,flush=True)
  if i%1000==0:print(name,'visited',i,'seen',len(seen),'calls',calls,'sizes',sorted(counts),'sec',time.monotonic()-start,flush=True)
 d={'name':name,'parent_order':N,'closed_sets_found':len(seen)-1,'closed_sets_processed':i,'complete':i==len(queue),'seconds':time.monotonic()-start,'closure_calls':calls,'size_counts':counts,'new_size_witnesses':witnesses}
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 return d
if __name__=='__main__':
 import concurrent.futures
 jobs=[('cube8',nand3(),30,50000),('cube8_times_central4',product(nand3(),central(2)),120,50000),('cube8_square',product(nand3(),nand3()),120,50000),('cube8_times_central9',product(nand3(),central(3)),120,50000)]
 with concurrent.futures.ThreadPoolExecutor(2) as ex:list(ex.map(lambda t:run(*t),jobs))
