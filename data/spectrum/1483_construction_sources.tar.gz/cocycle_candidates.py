import numpy as np,itertools,random,collections,json,pathlib
from central_cocycles import components,table
P=pathlib.Path(__file__).resolve().parent
rot=lambda x:((x<<1)|(x>>2))&7
base=[[7^(rot(x)&rot(rot(y))) for y in range(8)]for x in range(8)]
C=components(base);rng=random.Random(1483)
failures=[]
for seed in range(100):
 ps=[rng.choice(((0,1),(1,0))) for _ in C];T=np.array(table(base,ps));n=len(T);I=np.arange(n)
 for a in range(n):
  # P[b,t] = a*(t*b).
  V=T[a,T.T]
  for b in range(n):
   bad=np.flatnonzero(V[b,V[b]]!=V[b])
   if len(bad):failures.append({'name':'projector_idempotence','seed':seed,'parameters':[a,b,int(bad[0])]});break
   good=I[V[b]==I]
   w=V[:,good];bad=np.argwhere(V[b,w]!=w)
   if len(bad):failures.append({'name':'fixed_preservation','seed':seed,'parameters':[a,b,int(bad[0,0]),int(good[bad[0,1]])]});break
  if failures:break
 if failures:break
 for e in range(n):
  for a in set(T[e]):
   for b in set(T[a]):
    t=T[e,b]
    if t==a:continue
    R=np.unique(T[t]);w=T[t,T[R,a]]
    bad=np.flatnonzero(w!=R)
    if len(bad):failures.append({'name':'absorption','seed':seed,'parameters':[e,int(a),int(b),int(R[bad[0]])]});break
    if T[a,T[b,t]]==b:failures.append({'name':'collapse','seed':seed,'parameters':[e,int(a),int(b)]});break
   if failures:break
  if failures:break
 if failures:break
out={'trials':seed+1,'failures':failures,'trust':'Finite checks only; not universal proofs.'}
if failures:out.update({'table':T.tolist(),'permutations':ps})
(P/'cocycle-candidates.json').write_text(json.dumps(out,indent=2)+'\n')
print(out if not failures else failures)
