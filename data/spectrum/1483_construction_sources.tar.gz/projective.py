"""E1483 completions on projective polarity/correlation graphs over prime fields."""
import itertools,json,time,pathlib,collections
P=pathlib.Path(__file__).resolve().parent

def normalize(v,p):
 for a in v:
  if a%p:
   inv=pow(a,-1,p);return tuple(x*inv%p for x in v)
 raise ValueError('zero')
def points(p):return sorted({normalize(v,p) for v in itertools.product(range(p),repeat=3) if any(v)})
def det(M,p):
 a,b,c,d,e,f,g,h,i=M
 return (a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g))%p
def domains(p,M):
 V=points(p);n=len(V)
 A=[[sum(V[x][i]*M[3*i+j]*V[y][j] for i in range(3) for j in range(3))%p==0 for y in range(n)] for x in range(n)]
 D=[[{z for z in range(n) if A[x][z] and A[z][y]} for y in range(n)] for x in range(n)]
 assert all(len(s) in (1,p+1) for row in D for s in row)
 return V,A,D

def propagate(D):
 n=len(D);T=[[next(iter(s)) if len(s)==1 else None for s in row] for row in D];rounds=0
 while True:
  changed=False;rounds+=1
  for x,y,z in itertools.product(range(n),repeat=3):
   a,b=T[y][x],T[y][z]
   if a is None or b is None:continue
   c=T[x][b]
   if c is None:continue
   if x not in D[a][c]:return False,{'law_instance':[x,y,z],'outer_cell':[a,c],'required':x,'allowed':sorted(D[a][c]),'rounds':rounds},T
   if T[a][c] is None:
    D[a][c]={x};T[a][c]=x;changed=True
   elif T[a][c]!=x:return False,{'law_instance':[x,y,z],'outer_cell':[a,c],'required':x,'old':T[a][c],'rounds':rounds},T
  if not changed:return True,None,T

def run(p,all_matrices=True):
 start=time.monotonic();counts=collections.Counter();survivors=[];examples=[];seen=0
 for M in itertools.product(range(p),repeat=9):
  if not det(M,p):continue
  if next(x for x in M if x)!=1:continue # projective scalar equivalence
  seen+=1;V,A,D=domains(p,M);ok,w,T=propagate(D)
  counts['unresolved' if ok else 'contradiction']+=1
  if ok:survivors.append({'matrix':M,'domains':[[sorted(s) for s in row] for row in D]})
  elif len(examples)<4:examples.append({'matrix':M,'contradiction':w})
  if seen%500==0:print(p,seen,dict(counts),'sec',time.monotonic()-start,flush=True)
  if not all_matrices and seen>=20:break
 d={'prime':p,'order':p*p+p+1,'matrices':seen,'counts':dict(counts),'seconds':time.monotonic()-start,'survivors':survivors,'examples':examples,'trust':'Direct propagation of necessary E1483 instances on the specified graph domains. Not a general order exclusion and not Lean checked.'}
 (P/f'projective{p}.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in('survivors','examples')}),flush=True)
if __name__=='__main__':
 run(2);run(3)
