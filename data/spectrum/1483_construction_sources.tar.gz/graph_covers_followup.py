import itertools,json,time,pathlib,concurrent.futures
from pysat.formula import IDPool
from pysat.card import CardEnc,EncType
from pysat.solvers import Solver
from projective import domains,det
P=pathlib.Path(__file__).resolve().parent

def solve(job):
 p,M,m,seconds=job
 if p == 0:
  k=M[0];V=list(itertools.combinations(range(3*k),k));A=[[set(x).isdisjoint(y) for y in V]for x in V];D0=[[{z for z in range(len(V)) if A[x][z] and A[z][y]} for y in range(len(V))]for x in range(len(V))]
 else: V,A,D0=domains(p,M)
 base_n=len(V);n=m*base_n
 D=[[tuple(m*z+j for z in sorted(D0[x//m][y//m]) for j in range(m)) for y in range(n)] for x in range(n)]
 start=time.monotonic();pool=IDPool();solver=Solver(name='cadical195');cnt=0
 def lit(x,y,z):return pool.id((x,y,z)) if z in D[x][y] else None
 def add(cl):
  nonlocal cnt
  solver.add_clause(cl);cnt+=1
 for x,y in itertools.product(range(n),repeat=2):
  for cl in CardEnc.equals([lit(x,y,z) for z in D[x][y]],1,vpool=pool,encoding=EncType.seqcounter):add(cl)
 for x,y,z in itertools.product(range(n),repeat=3):
  for a,b in itertools.product(D[y][x],D[y][z]):
   for c in D[x][b]:
    cl=[-lit(y,x,a),-lit(y,z,b),-lit(x,b,c)];v=lit(a,c,x)
    if v is not None:cl.append(v)
    add(cl)
  for a,b in itertools.product(D[x][y],D[z][y]):
   for c in D[b][x]:
    cl=[-lit(x,y,a),-lit(z,y,b),-lit(b,x,c)];v=lit(c,a,x)
    if v is not None:cl.append(v)
    add(cl)
 encoded=time.monotonic()-start;ans=None
 print('encoded',p,M,m,n,encoded,cnt,flush=True)
 while time.monotonic()-start<seconds:
  solver.conf_budget(1000);ans=solver.solve_limited()
  if ans is not None:break
 T=None
 if ans:
  model=set(solver.get_model());T=[[next(z for z in D[x][y] if lit(x,y,z) in model)for y in range(n)]for x in range(n)]
  assert all(T[T[y][x]][T[x][T[y][z]]]==x for x,y,z in itertools.product(range(n),repeat=3))
 solver.delete();out={'prime':p,'matrix':M,'multiplicity':m,'order':n,'status':'sat' if ans else 'unsat' if ans is False else 'unknown','table':T,'seconds':time.monotonic()-start,'encoding_seconds':encoded,'variables':pool.top,'clauses':cnt,'budget':seconds,'trust':'Restricted projective graph cover; not a general spectrum exclusion, no Lean certificate.'}
 (P/('projective-cover-'+str(p)+'-'+str(m)+'-'+''.join(map(str,M))+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
if __name__=='__main__':
 jobs=[(2,(1,0,0,0,1,0,0,0,1),3,90),(0,(2,),1,90)]
 with concurrent.futures.ProcessPoolExecutor(2) as ex:list(ex.map(solve,jobs))
