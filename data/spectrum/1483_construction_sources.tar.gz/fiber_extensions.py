"""Small, structured extensions of the natural four-point central groupoid."""
import itertools,pathlib,json,time,concurrent.futures
from pysat.solvers import Solver
from pysat.formula import IDPool
from pysat.card import CardEnc,EncType
P=pathlib.Path(__file__).resolve().parent

def patterns(n):
 for a in (1,2,4,8,9):
  for d in (1,2,4,8,9):
   if a>d:continue
   for b in range(1,n):
    c=n-a-d-b
    if b>c or c<=0:continue
    sizes=[[a,b],[c,d]]
    if all(sizes[i][j]<=sizes[k][i]*sizes[j][k] for i,j,k in itertools.product(range(2),repeat=3)):
     yield [a,b,c,d]

def search(shape,seconds=90):
 start=time.monotonic();fibers=[];coords=[]
 for k,n in enumerate(shape):
  fibers.append(list(range(len(coords),len(coords)+n)));coords.extend([(k//2,k%2)]*n)
 n=len(coords);D=[[fibers[2*coords[x][1]+coords[y][0]] for y in range(n)] for x in range(n)]
 pool=IDPool();truth=pool.id('true');S=Solver(name='cadical195');S.add_clause([truth]);clauses=1
 def lit(x,y,z):
  ds=D[x][y]
  if z not in ds:return -truth
  if len(ds)==1:return truth
  return pool.id((x,y,z))
 def add(vs):
  nonlocal clauses
  if truth in vs:return
  v=set(x for x in vs if x!=-truth)
  if any(-x in v for x in v):return
  S.add_clause(list(v));clauses+=1
 for x,y in itertools.product(range(n),repeat=2):
  if len(D[x][y])>1:
   for cl in CardEnc.equals([lit(x,y,z) for z in D[x][y]],1,vpool=pool,encoding=EncType.seqcounter):add(cl)
 # Each two-element diagonal fiber is a submagma. Exhaustive two-point
 # enumeration gives NAND and its relabeling, so choose NAND on that fiber.
 for k in (0,3):
  F=fibers[k]
  if len(F)==2:
   for x,y in itertools.product(range(2),repeat=2):add([lit(F[x],F[y],F[1-x*y])])
 for x,y,z in itertools.product(range(n),repeat=3):
  for a,b in itertools.product(D[y][x],D[y][z]):
   for c in D[x][b]:add([-lit(y,x,a),-lit(y,z,b),-lit(x,b,c),lit(a,c,x)])
  for a,b in itertools.product(D[x][y],D[z][y]):
   for c in D[b][x]:add([-lit(x,y,a),-lit(z,y,b),-lit(b,x,c),lit(c,a,x)])
 encoded=time.monotonic()-start;result=None
 while time.monotonic()-start<seconds:
  S.conf_budget(1000);result=S.solve_limited()
  if result is not None:break
 table=None
 if result:
  model=set(S.get_model());table=[[next(z for z in D[x][y] if lit(x,y,z) in model) for y in range(n)] for x in range(n)]
  assert all(table[table[y][x]][table[x][table[y][z]]]==x for x,y,z in itertools.product(range(n),repeat=3))
 S.delete()
 d={'order':n,'fiber_sizes':shape,'status':'sat' if result else 'unsat' if result is False else 'unknown','table':table,'seconds':time.monotonic()-start,'encoding_seconds':encoded,'variables':pool.top,'clauses':clauses,'budget':seconds,'trust':'Restricted extension search; UNSAT is not a general order exclusion or a Lean proof.'}
 (P/('fibers-'+str(n)+'-'+'-'.join(map(str,shape))+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 return d
if __name__=='__main__':
 tables=[]
 for flat in itertools.product(range(2),repeat=4):
  T=[flat[:2],flat[2:]]
  if all(T[T[y][x]][T[x][T[y][z]]]==x for x,y,z in itertools.product(range(2),repeat=3)):tables.append(flat)
 assert set(tables)=={(1,1,1,0),(1,0,0,0)}
 jobs=[p for n in (12,13) for p in patterns(n)];print('patterns',jobs,flush=True)
 with concurrent.futures.ProcessPoolExecutor(2) as ex:list(ex.map(search,jobs))
