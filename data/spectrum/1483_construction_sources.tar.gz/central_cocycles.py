import itertools,collections,json,pathlib
P=pathlib.Path(__file__).resolve().parent

def components(T):
 parent={}
 def root(x):
  parent.setdefault(x,x)
  if parent[x]!=x:parent[x]=root(parent[x])
  return parent[x]
 def join(x,y):parent[root(x)]=root(y)
 n=len(T)
 for x,y,z in itertools.product(range(n),repeat=3):
  a=T[y][x];b=T[x][T[y][z]]
  join(('B',a,b),('A',y,x))
  join(('A',a,b),('B',x,T[y][z]))
 groups={}
 for typ in ('A','B'):
  for i,j in itertools.product(range(n),repeat=2):
   a=(typ,i,j);groups.setdefault(root(a),[]).append(a)
 return list(groups.values())

def table(T,perms):
 comps=components(T);q=len(perms[0]);A={};B={}
 for C,perm in zip(comps,perms):
  inv=[perm.index(i) for i in range(q)]
  for typ,i,j in C:(A if typ=='A' else B)[i,j]=perm if typ=='A' else inv
 V=list(itertools.product(range(len(T)),range(q),range(q)));ix={v:i for i,v in enumerate(V)}
 return [[ix[(T[x][y],B[x,y][b],A[x,y][c])] for y,c,d in V] for x,a,b in V]

def witness(T,weak=False):
 n=len(T)
 return next(([x,y,z] for x,y,z in itertools.product(range(n),repeat=3) if T[T[y][x]][T[x][T[z][y] if weak else T[y][z]]]!=x),None)

def run(T,label,q=2):
 C=components(T);out=[];profiles=collections.Counter()
 for permutations in itertools.product(list(itertools.permutations(range(q))),repeat=len(C)):
  U=table(T,permutations)
  assert witness(U) is None
  w=witness(U,True);ranks=tuple(sorted(collections.Counter(len(set(row)) for row in U).items()))
  profiles[(w is not None,ranks)]+=1
  if w is not None and len(out)<4:out.append({'permutations':permutations,'table':U,'E1485_failure':w,'ranks':ranks})
 d={'label':label,'base':T,'components':C,'q':q,'profiles':[(str(k),v) for k,v in profiles.items()],'examples':out}
 (P/f'cocycles-{label}.json').write_text(json.dumps(d,indent=2)+'\n')
 print(label,len(C),profiles,flush=True)
if __name__=='__main__':
 run([[1,1],[1,0]],'nand2')
 run([[2*(x%2)+y//2 for y in range(4)] for x in range(4)],'central4')
