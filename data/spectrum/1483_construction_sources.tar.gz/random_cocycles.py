import itertools,collections,random,json,pathlib
from central_cocycles import components,table,witness
P=pathlib.Path(__file__).resolve().parent
rot=lambda x:((x<<1)|(x>>2))&7
T=[[7^(rot(x)&rot(rot(y))) for y in range(8)]for x in range(8)]
C=components(T);rng=random.Random(1483);profiles=collections.Counter();examples=[]
for seed in range(100):
 perms=[rng.choice(((0,1),(1,0))) for _ in C]
 U=table(T,perms)
 assert witness(U) is None
 counts=collections.Counter(len(set(row)) for row in U);small=min(counts)
 dyadic=all(r%small==0 and (r//small)&(r//small-1)==0 for r in counts)
 rows=len(set(tuple(sorted(set(row))) for row in U))
 profile=(tuple(sorted(counts.items())),rows,dyadic);profiles[profile]+=1
 if not dyadic or len(examples)<3:examples.append({'seed':seed,'table':U,'permutations':perms,'ranks':sorted(counts.items()),'dyadic':dyadic,'distinct_row_images':rows,'E1485_failure':witness(U,True)})
 if not dyadic:print('NON-DYADIC!',seed,profile,flush=True);break
out={'base':T,'components':C,'trials':seed+1,'profiles':[(str(k),v) for k,v in profiles.items()],'examples':examples}
(P/'cocycles-cube8.json').write_text(json.dumps(out,indent=2)+'\n')
print('components',len(C),'profiles',profiles,flush=True)
