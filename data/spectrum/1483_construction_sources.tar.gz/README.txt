E1483 general constructions, 26 September 2026.

All files are flat; extract into a fresh directory. The .py scripts write their
results beside themselves. subalgebras.py, projective.py and central_cocycles.py
use only the standard library. The finite SAT search scripts require python-sat;
cocycle_candidates.py requires numpy. random_cocycles.py uses random seed 1483.

The SAT results restrict a construction family; they are NOT general order
exclusions and have no Lean certificates. In graph_covers_followup.py the
sentinel prime=0, matrix=(2,) denotes KG(6,2), not a projective plane or a field.
The other records with positive prime describe projective correlation graphs.

The actual Lean sources and the complete mathematical arguments are in the
repository, not this archive. No spectrum bound changes in this pass.
