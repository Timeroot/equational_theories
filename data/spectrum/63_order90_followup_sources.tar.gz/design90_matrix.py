from ortools.sat.python import cp_model
from itertools import combinations
import json,sys,time
from pathlib import Path
out=Path('/tmp/e63-order90-20260925');m=cp_model.CpModel();q=11
# Seven complements of lines in the Fano plane on nonzero vectors of F_2^3.
lines=[{a,b,a^b} for a,b in combinations(range(1,8),2)];lines=sorted(set(tuple(sorted(l)) for l in lines))
supports=[[i for i in range(7) if i+1 not in line]+[7] for line in lines]
rows=[]
for r in range(7):
 rows.append([0 if r==0 or i==7 else m.new_int_var(0,10,f'f_{r}_{i}') for i in range(8)])
for r,sup in enumerate(supports):
 rows.append([None if i not in sup else 0 if i==7 else m.new_int_var(0,10,f'p_{r}_{i}') for i in range(8)])
for r in range(2):
 rows.append([None if i==7 else 0 if i==0 else m.new_int_var(0,10,f'a_{r}_{i}') for i in range(8)])
for i,j in combinations(range(8),2):
 ds=[]
 for r,row in enumerate(rows):
  if row[i] is None or row[j] is None:continue
  d=m.new_int_var(0,10,f'd_{r}_{i}_{j}');m.add_modulo_equality(d,row[i]-row[j]+11,11);ds.append(d)
 assert len(ds)==11,(i,j,len(ds));m.add_all_different(ds)
for r in range(1,6):m.add(rows[r][0]<rows[r+1][0])
m.add(rows[14][1]<rows[15][1])
# An extra restriction is optional, used only to seek witnesses faster.
if len(sys.argv)>1 and sys.argv[1]=='linear':
 for i in range(7):m.add(rows[14][i]==i)
s=cp_model.CpSolver();s.parameters.max_time_in_seconds=600;s.parameters.num_search_workers=4;s.parameters.random_seed=90
s.parameters.log_search_progress=True
status=s.solve(m);print('RESULT',s.status_name(status),flush=True)
if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
 array=[[None if x is None else x if isinstance(x,int) else s.value(x) for x in row] for row in rows]
 groups=[list(range(11*i,11*(i+1))) for i in range(7)]+[list(range(77,90))]
 blocks=[]
 for r,row in enumerate(array):
  for k in range(11):
   b=[11*i+(a+k)%11 for i,a in enumerate(row) if a is not None]
   if r>=14:b.append(88+r-14)
   blocks.append(b)
 owner={x:i for i,g in enumerate(groups) for x in g}
 needed={p for p in combinations(range(90),2) if owner[p[0]]!=owner[p[1]]}
 covered=[tuple(sorted(p)) for b in blocks for p in combinations(b,2)]
 assert set(covered)==needed and len(covered)==len(needed)
 (out/'gdd90.json').write_text(json.dumps({'groups':groups,'blocks':blocks,'matrix':array},indent=2))
 print('VERIFIED DESIGN 90',flush=True)
