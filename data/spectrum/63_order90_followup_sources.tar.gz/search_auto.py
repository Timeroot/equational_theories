import sys,json,time,subprocess,itertools
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_exhaustive import base_cnf, variable
from spectrum_63_bennett import prime
from spectrum_63_atp import validate
from pysat.formula import CNF
out=Path('/tmp/e63-order90-20260925')
# A 5-cycle on the prescribed submodel, and two 5-cycles plus a fixed point outside.
n=16
p=[(i//5)*5+(i+1)%5 if i<15 else 15 for i in range(n)]
f=base_cnf(n)
t=prime(5)
for x in range(5):
 for y in range(5):f.append([variable(n,x,y,t[x][y])])
for x,y,z in itertools.product(range(n),repeat=3):
 a,b=variable(n,x,y,z),variable(n,p[x],p[y],p[z])
 f.extend([[-a,b],[a,-b]])
f.to_file(out/'auto5.cnf')
with (out/'auto5.log').open('w') as log:
 r=subprocess.run(['cadical','-t','300',str(out/'auto5.cnf')],stdout=log,stderr=subprocess.STDOUT)
print('exit',r.returncode,flush=True)
if r.returncode==10:
 vals={int(v) for line in (out/'auto5.log').read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
 t=[[next(z for z in range(n) if variable(n,x,y,z) in vals) for y in range(n)] for x in range(n)]
 validate(t,n,229)
 (out/'model16auto5.json').write_text(json.dumps(t))
 print('MODEL VERIFIED',flush=True)
