import sys,json,itertools,time,subprocess
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import td,restrict,glue,build
from pysat.card import CardEnc, EncType
from pysat.formula import CNF
q,k,target=map(int,sys.argv[1:4]);p=int(sys.argv[4]) if len(sys.argv)>4 else 0
out=Path('/tmp/e63-order90-20260925');groups,blocks=td(q,k);n=q*k;f=CNF();f.nv=n
known={0,1,3,4,5,7,8,9,11,12,13,15,16,17,19,20,21,22,23,24,25,27,28,29,31,32,33,34,35,36,37,39,40,41,43,44,45,46,47}
idem={0,1,5,7,8,11,17,19,23,25,27,29,31,35,37,41,43}
def restrict_counts(points,allowed):
 for s in range(len(points)+1):
  if s in allowed:continue
  for comb in itertools.combinations(points,s):
   c=set(comb);f.append([-x if x in c else x for x in points])
f.extend(CardEnc.equals(list(range(1,n+1)),bound=n+p-target,top_id=f.nv,encoding=EncType.seqcounter).clauses)
for g in groups:restrict_counts([x+1 for x in g],{q-a for a in known if 0<=q-a<=q})
for b in blocks:restrict_counts([x+1 for x in b],{k-a for a in idem if 0<=k-a<=k})
name=f'delete-{q}-{k}-{target}';f.to_file(out/(name+'.cnf'));start=time.time()
with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t','300',str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
print(name,r.returncode,time.time()-start,flush=True)
if r.returncode==10:
 vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
 removed=[x for x in range(n) if x+1 in vals];gg,bb=restrict(groups,blocks,set(removed))
 d={'q':q,'k':k,'removed':removed,'groups':gg,'blocks':bb};(out/(name+'.json')).write_text(json.dumps(d))
 print('DESIGN', [len(g) for g in gg], 'blocks', {a:sum(len(b)==a for b in bb) for a in range(k+1)},flush=True)
