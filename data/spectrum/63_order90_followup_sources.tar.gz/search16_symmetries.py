import sys,json,subprocess,itertools,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_exhaustive import base_cnf,variable
from spectrum_63_bennett import prime
from spectrum_63_atp import validate
from pysat.formula import CNF
out=Path('/tmp/e63-order90-20260925');n=16;base=base_cnf(n);t=prime(5)
for x in range(5):
 for y in range(5):base.append([variable(n,x,y,t[x][y])])
cases=[(2,[1]*3+[2]*4),(2,[1]*7+[2]*2),(4,[1]*3+[4]*2),(4,[1]*3+[2]*2+[4]),(4,[1]*7+[4])]
report=[]
for order,cs in cases:
 mult=4 if order==2 else 2
 p=[mult*i%5 for i in range(5)];offset=5
 for k in cs:
  p.extend(offset+(i+1)%k for i in range(k));offset+=k
 assert offset==n
 f=CNF();f.nv=base.nv;f.extend(base.clauses)
 for x,y,z in itertools.product(range(n),repeat=3):
  a,b=variable(n,x,y,z),variable(n,p[x],p[y],p[z]);f.extend([[-a,b],[a,-b]])
 name=f'sym16-{order}-'+ '-'.join(map(str,cs));f.to_file(out/(name+'.cnf'));start=time.time()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t','180',str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
 print(name,'exit',r.returncode,'seconds',round(time.time()-start,2),flush=True)
 report.append({'name':name,'permutation':p,'exit_code':r.returncode,'seconds':time.time()-start})
 if r.returncode==10:
  vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
  t=[[next(z for z in range(n) if variable(n,x,y,z) in vals) for y in range(n)] for x in range(n)]
  validate(t,n,229);(out/(name+'.json')).write_text(json.dumps(t));print('MODEL VERIFIED',flush=True);break
(out/'sym16-report.json').write_text(json.dumps(report,indent=2))
