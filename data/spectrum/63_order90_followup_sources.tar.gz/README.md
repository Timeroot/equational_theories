# E63 order-90 follow-up, 2026-09-25

These are research searches, not Lean proof certificates. Run Python scripts
from the equational_theories repository root. They import the existing scripts/
helpers. The working paths in these saved sources are rooted at
/tmp/e63-order90-20260925; extract this bundle there to reproduce the paths.
Searches require python-sat, OR-Tools, and CaDiCaL as appropriate. Checking
actual multiplication tables uses scripts/spectrum_63_atp.py:validate.

Principal replay commands:

    python3 /tmp/e63-order90-20260925/isotope16.py
    python3 /tmp/e63-order90-20260925/search_isotope16.py
    python3 /tmp/e63-order90-20260925/design90_matrix.py
    python3 /tmp/e63-order90-20260925/design90_patterns.py B
    python3 /tmp/e63-order90-20260925/design90_patterns.py C
    python3 /tmp/e63-order90-20260925/search16_strong.py
    python3 /tmp/e63-order90-20260925/search16_count.py
    python3 /tmp/e63-order90-20260925/search16_count_f5.py
    python3 /tmp/e63-order90-20260925/search16_count_f8.py
    python3 /tmp/e63-order90-20260925/search_partial_strong.py 13 2 600
    python3 /tmp/e63-order90-20260925/search_partial_strong.py 15 4 600

The last two order-16 searches fix the first subquasigroup point's outside
cycles to 1,1,3,3,3. They search a branch, not all order-16 tables.
The f5/f8 variants use outside cycle types 1^5 3^2 and 1^8 3.
search16_count.py additionally implements the counting constraints proved
in docs/63_order90.md. That saved version allows all nine (k,epsilon) pairs
listed in the note, including length-6/9/12/15 noncommuting cycles.

The isotope audit searches both possible five-element Latin subsquares of
the saved singular-product table. INFEASIBLE is a CP-SAT outcome without an
independently checked proof trace; it is not a Lean theorem, and it says
nothing about order-16 tables outside this isotopy class.

The difference-matrix scripts check every required difference and every
covered pair before exporting a positive design. Patterns A/B/C correspond
to the table in docs/63_order90.md. The optimization variant can return
FEASIBLE at a positive collision score; only score zero would be a design.
No candidate matrix with collisions is a positive certificate.

The abandoned 29-point GDD searches are included to document the attempted
route. They were stopped after the elementary counting obstruction in
that note was established. They should not be rerun for this target.

No SAT/CP refutation in this bundle has an independently checked proof trace.
No failed search is an order-90 nonexistence theorem.
