import sys,json,subprocess,itertools,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_exhaustive import base_cnf,variable,add_commuting_triangles
from spectrum_63_bennett import prime
from spectrum_63_atp import validate
out=Path('/tmp/e63-order90-20260925');n=16;f=base_cnf(n);p=prime(5);v=lambda x,y,z:variable(n,x,y,z)
for i in range(3):
 for x,y in itertools.product(range(5),repeat=2):
  if x!=y or i==0:f.append([v(5*i+x,5*i+y,5*i+p[x][y])])
for x,y in itertools.combinations(range(n),2):
 if x//5==y//5:continue
 for z in range(n):f.extend([[-v(x,y,z),v(y,x,z)],[v(x,y,z),-v(y,x,z)]])
add_commuting_triangles(f,n)
name='threeblocks16';f.to_file(out/(name+'.cnf'));start=time.time()
with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t','300',str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
print(name,'exit',r.returncode,'seconds',time.time()-start,flush=True)
if r.returncode==10:
 vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
 t=[[next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
 validate(t,n,229);(out/(name+'.json')).write_text(json.dumps(t));print('MODEL VERIFIED',flush=True)
