import sys,json,time,subprocess,itertools
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_partial import encode,check,same_hole,layout
from spectrum_63_exhaustive import add_commuting_triangles
from pysat.formula import CNF
out=Path('/tmp/e63-order90-20260925');n,h=map(int,sys.argv[1:3]);seconds=int(sys.argv[3]) if len(sys.argv)>3 else 300
spec={'order':n,'hole_size':h};owner=layout(spec);v=lambda x,y,z:1+(x*n+y)*n+z
f=CNF();top,cl=encode(spec);f.nv=top;f.extend(cl)
for y,x,a,b in itertools.product(range(n),repeat=4):
 if any(same_hole(owner,u,w) for u,w in [(y,x),(y,a),(b,y)]):continue
 av,bv,cv=v(y,x,a),v(y,a,b),v(b,y,x)
 f.extend([[-av,bv,-cv],[av,-bv,-cv]])
for x,y,z in itertools.product(range(n),repeat=3):
 if y!=z:f.append([-v(x,y,z),-v(x,z,y)])
# Commutation is constant on each defined multiplication triangle.
cs={}
f.nv+=1;truth=f.nv;f.append([truth])
for x in range(n):cs[x,x]=truth
for x,y in itertools.combinations(range(n),2):
 if same_hole(owner,x,y):cs[x,y]=cs[y,x]=truth;continue
 f.nv+=1;c=f.nv;cs[x,y]=cs[y,x]=c
 for z in range(n):f.extend([[-v(x,y,z),-v(y,x,z),c],[-c,-v(x,y,z),v(y,x,z)]])
for x,y,z in itertools.product(range(n),repeat=3):
 e=v(x,y,z);a,b,c=cs[x,y],cs[x,z],cs[y,z]
 f.extend([[-e,-a,b],[-e,a,-b],[-e,-a,c],[-e,a,-c]])
name=f'strong-hole{n}-{h}';f.to_file(out/(name+'.cnf'));start=time.time()
with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t',str(seconds),str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
print(name,'exit',r.returncode,'seconds',time.time()-start,flush=True)
if r.returncode==10:
 vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
 spec['table']=[[None if same_hole(owner,x,y) else next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
 check(spec);(out/(name+'.json')).write_text(json.dumps(spec));print('PARTIAL MODEL VERIFIED',flush=True)
