"""Preserve this bounded search pass; run only after its searches finish."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
from importlib.metadata import version
root=Path('/tmp/e63-order90-20260925');dest=Path('data/spectrum')
assert not any((root/name).exists() for name in ['model90.json','gdd90.json','matrix_solution.json']), 'A positive certificate requires integration, not a failure report.'
def sat(name):
 text=(root/(name+'.log')).read_text()
 assert re.search(r'^c exit (?:0|10|20)$',text,re.M),f'{name} is not finished'
 if re.search(r'^s SATISFIABLE$',text,re.M):raise RuntimeError('Positive model found: '+name)
 status='UNSAT_NO_PROOF_TRACE' if re.search(r'^s UNSATISFIABLE$',text,re.M) else 'UNRESOLVED'
 sec=re.search(r'total process time since initialization:\s*([\d.]+)',text)
 return {'status':status,'solver_cpu_seconds':float(sec[1]) if sec else None,'cnf_sha256':hashlib.sha256((root/(name+'.cnf')).read_bytes()).hexdigest()}
def cp(name):
 text=(root/(name+'.log')).read_text()
 status=re.search(r'^RESULT (\w+)$',text,re.M)
 assert status,name
 return {'status':status[1],'seconds':float(re.search(r'walltime: ([\d.]+)',text)[1])}
report={'law':63,'order':90,'date':'2026-09-25','status':'UNRESOLVED','positive_certificates':[],
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'solver_versions':{'cadical':subprocess.check_output(['cadical','--version'],text=True).strip(),'ortools':version('ortools'),'python_sat':version('python-sat')},
 'interpretation':'Research outcomes only. No new Lean proof or admission at order 90. Solver refutations have no independently checked proof traces.',
 'mathematical_findings':[
  'Every finite constant-diagonal E229 quasigroup, and every nonempty subquasigroup of one, has order 1 modulo 3. The reconstructed singular product of order 16 therefore cannot contain a subquasigroup of order 5.',
  'The proposed {5,7,8}-GDD of type 3^9 2^1 is impossible by elementary block counting; searches for that replacement route were stopped.',
  'For an outside point in a 16-model with a 5-subquasigroup, noncommuting partners inside/outside and row fixed points satisfy the counts in docs/63_order90.md.'
 ],
 'isotope_audit':{'subsquares':json.loads((root/'singular16-subsquares.json').read_text())['subsquares'],
  'solver_outcomes':re.findall(r'^([01]) (INFEASIBLE)$',(root/'isotope16_audit.log').read_text(),re.M),
  'scope':'All isotopes of the saved singular-product table which could have a 5-subquasigroup, up to isomorphism. Not all 16-element tables.'},
 'partial_tables':{
  '13_with_hole_2_initial':json.loads((root/'hole13-2/result.json').read_text()),
  '13_with_hole_2_strengthened':sat('strong-hole13-2'),
  '15_with_hole_4_strengthened':sat('strong-hole15-4')},
 'order16_sub5':{
  'first_row_outside_cycles':[1,1,3,3,3],
  'scope':'This fixed first-row branch only; no exhaustive nonexistence claim.',
  'strong':sat('strong16-sub5'),'with_counting_constraints':sat('count16-sub5'),
  'other_commuting_first_rows':{'five_fixed':sat('count16-sub5-f5'),'eight_fixed':sat('count16-sub5-f8')},
  'symmetry_searches':json.loads((root/'sym16-report.json').read_text())},
 'cyclic_GDD_11_7_13':{'A':cp('design90_matrix'),'B':cp('design90_B'),'C':cp('design90_C'),
  'optimization_A':dict(cp('design90_opt'),best_collision_score=27,interpretation='Positive collision score: not a design certificate.'),
  'with_redundant_sums':{'A_fixed_two_full_rows':cp('design90_sums2'),'B':cp('design90_B_sums')}},
 'truncation_TD_8_13':sat('delete-13-8-90'),
 'discarded_GDD_3_9_2':{'status':'STOPPED_AFTER_MATHEMATICAL_OBSTRUCTION','note':'docs/63_order90.md'},
}
assert len(report['isotope_audit']['solver_outcomes'])==2
paths=sorted([p for p in root.iterdir() if p.suffix in {'.py','.cpp','.log'} or p.name in {'README.md','singular16-subsquares.json','sym16-report.json','matrix_best.json'}])
paths += [root/'hole13-2/result.json',root/'hole13-2/solver.log']
archive=dest/'63_order90_followup_sources.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w|') as tar:
   for p in paths:
    data=p.read_bytes();t=tarfile.TarInfo(str(p.relative_to(root)));t.size=len(data);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(data))
report['source_archive']={'file':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(paths)}
(dest/'63_order90_followup.json').write_text(json.dumps(report,indent=2)+'\n')
print('Recorded unresolved search pass and archived',len(paths),'small sources/logs.')
