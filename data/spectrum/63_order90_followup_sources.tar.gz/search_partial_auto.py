import sys,json,subprocess,itertools
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_partial import encode,check,same_hole,layout
from pysat.formula import CNF
out=Path('/tmp/e63-order90-20260925')
n,h=map(int,sys.argv[1:3]);typ=sys.argv[3]
spec={'order':n,'hole_size':h}
v=lambda x,y,z:1+(x*n+y)*n+z
if typ=='cycle':p=list(range(h))+[h+(i-h+1)%(n-h) for i in range(h,n)]
else:raise ValueError(typ)
f=CNF();top,cl=encode(spec);f.nv=top;f.extend(cl)
for x,y,z in itertools.product(range(n),repeat=3):
 a,b=v(x,y,z),v(p[x],p[y],p[z]);f.extend([[-a,b],[a,-b]])
name=f'auto-hole{n}-{h}-{typ}';f.to_file(out/(name+'.cnf'))
with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t','300',str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
print(name,'exit',r.returncode,flush=True)
if r.returncode==10:
 vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
 owner=layout(spec);spec['table']=[[None if same_hole(owner,x,y) else next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
 check(spec);(out/(name+'.json')).write_text(json.dumps(spec));print('PARTIAL MODEL VERIFIED',flush=True)
