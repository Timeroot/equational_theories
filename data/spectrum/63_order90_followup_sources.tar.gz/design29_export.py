import sys
sys.modules['pyarrow']=None
from ortools.sat.python import cp_model
from itertools import combinations, product
from pathlib import Path
import json,time
out=Path('/tmp/e63-order90-20260925');groups=[list(range(3*i,3*i+3)) for i in range(9)]+[[27,28]]
p=[3*((x//3)^1)+x%3 if x<24 else x if x<27 else 55-x for x in range(29)]
owner={x:i for i,g in enumerate(groups) for x in g};edges=[z for z in combinations(range(29),2) if owner[z[0]]!=owner[z[1]]];edgeid={z:i for i,z in enumerate(edges)}
m=cp_model.CpModel();cover=[[] for _ in edges];orbits=[];vs=[]
for k in [5,7,8]:
 count=0
 for gi in combinations(range(10),k):
  for pts in product(*(groups[i] for i in gi)):
   b=tuple(sorted(pts));bb=tuple(sorted(p[x] for x in b))
   if bb<b:continue
   if bb!=b and len(set(b)&set(bb))>1:continue
   bs=[b] if bb==b else [b,bb]
   es=[edgeid[e] for z in bs for e in combinations(z,2)]
   if len(set(es))!=len(es):continue
   v=m.new_bool_var('b'+str(len(vs)));vs.append(v);orbits.append(bs)
   for e in es:cover[e].append(v)
   count+=1
 print('size',k,'orbits',count,flush=True)
for c in cover:m.add_exactly_one(c)
reps=sorted({min(e,tuple(sorted(p[x] for x in e))) for e in edges})
ridx={e:i for i,e in enumerate(reps)}
with (out/'design29.dlx').open('w') as f:
 print(len(reps),len(orbits),file=f)
 for bs in orbits:
  es=sorted({ridx[min(e,tuple(sorted(p[x] for x in e)))] for b in bs for e in combinations(b,2)})
  print(len(es),*es,file=f)
(out/'design29-orbits.json').write_text(json.dumps({'groups':groups,'orbits':orbits}))
print('EXPORTED DLX',len(reps),len(orbits),flush=True)
