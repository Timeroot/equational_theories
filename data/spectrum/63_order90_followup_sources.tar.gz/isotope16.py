import sys,json,itertools,collections
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import prime,gf_affine,singular
from spectrum_63_atp import validate
out=Path('/tmp/e63-order90-20260925');t=singular(prime(5),gf_affine(4,7,2,2),prime(3,False));validate(t,16,229)
subs=[]
for r in itertools.combinations(range(16),5):
 cols=collections.defaultdict(list)
 for c in range(16):cols[tuple(sorted(t[x][c] for x in r))].append(c)
 for s,c in cols.items():
  if len(c)>=5:subs.append([list(r),c,list(s)])
print('SUBSQUARES',len(subs),subs[:10],flush=True)
(out/'singular16-subsquares.json').write_text(json.dumps({'table':t,'subsquares':subs}))
