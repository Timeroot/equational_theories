#include <bits/stdc++.h>
using namespace std;
int a[16][8]; vector<int> active[7];mt19937 rng(90);
int edgecost(int i,int j){int c[11]={};for(int r=0;r<16;r++)if(a[r][i]>=0&&a[r][j]>=0)c[(a[r][i]-a[r][j]+11)%11]++;int s=0;for(int t:c)s+=t*(t-1)/2;return s;}
int colcost(int i){int s=0;for(int j=0;j<7;j++)if(i!=j)s+=edgecost(i,j);return s;}
int cost(){int s=0;for(int i=0;i<7;i++)for(int j=i+1;j<7;j++)s+=edgecost(i,j);return s;}
void save(string fn){ofstream f(fn);f<<"[";for(int r=0;r<16;r++){if(r)f<<",";f<<"[";for(int c=0;c<8;c++){if(c)f<<",";if(a[r][c]<0)f<<"null";else f<<a[r][c];}f<<"]";}f<<"]\n";}
int main(int argc,char**argv){int secs=argc>1?atoi(argv[1]):600;auto start=chrono::steady_clock::now();set<set<int>> lines;for(int i=1;i<8;i++)for(int j=i+1;j<8;j++)lines.insert({i,j,i^j});memset(a,-1,sizeof(a));for(int r=0;r<7;r++)for(int c=0;c<8;c++)a[r][c]=0;int r=7;for(auto l:lines){for(int c=0;c<7;c++)if(!l.count(c+1))a[r][c]=0;a[r++][7]=0;}for(int r=14;r<16;r++)for(int c=0;c<7;c++)a[r][c]=0;for(int c=0;c<7;c++)for(int r=1;r<14;r++)if(a[r][c]>=0)active[c].push_back(r);
int best=999,restart=0;uniform_real_distribution<double> U(0,1);long long steps=0;
while(chrono::duration<double>(chrono::steady_clock::now()-start).count()<secs){restart++;for(int c=0;c<7;c++){vector<int> v(10);iota(v.begin(),v.end(),1);shuffle(v.begin(),v.end(),rng);for(int j=0;j<10;j++)a[active[c][j]][c]=v[j];a[14][c]=c?rng()%11:0;a[15][c]=c?rng()%11:0;}int curr=cost();
for(int it=0;it<200000;it++){steps++;int c=rng()%7;int r,s;bool sw=(c==0||rng()%12<10);if(sw){r=active[c][rng()%10];s=active[c][rng()%10];if(r==s)continue;}else{r=14+rng()%2;s=-1;}int old=colcost(c),val=a[r][c];if(sw)swap(a[r][c],a[s][c]);else a[r][c]=rng()%11;int delta=colcost(c)-old;double temp=0.18+1.25*pow(1.0-double(it%40000)/40000,2);if(delta<=0||U(rng)<exp(-delta/temp)){curr+=delta;}else{if(sw)swap(a[r][c],a[s][c]);else a[r][c]=val;}
if(curr<best){best=curr;cerr<<"best "<<best<<" steps "<<steps<<" sec "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";save("/tmp/e63-order90-20260925/matrix_best.json");if(best==0){save("/tmp/e63-order90-20260925/matrix_solution.json");return 0;}}
if(it%10000==0&&chrono::duration<double>(chrono::steady_clock::now()-start).count()>=secs)break;
}}
cerr<<"ENDED best "<<best<<" steps "<<steps<<" restarts "<<restart<<"\n";}
