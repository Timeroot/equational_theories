import sys,json,subprocess,itertools,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_partial import encode,check,same_hole,layout
from spectrum_63_bennett import prime
from pysat.formula import CNF
out=Path('/tmp/e63-order90-20260925');n=13;spec={'order':n,'hole_size':2};owner=layout(spec);v=lambda x,y,z:1+(x*n+y)*n+z
base=CNF();top,cl=encode(spec);base.nv=top;base.extend(cl);t=prime(5)
cases=[
 [[0,2,3,4,5],[1,6,7,8,9]],
 [[0,2,3,4,5],[6,7,8,9,10]],
 [[2,3,4,5,6],[7,8,9,10,11]],
 [[0,2,3,4,5],[0,6,7,8,9]],
 [[2,0,3,4,5],[2,1,6,7,8]],
 [[2,0,3,4,5],[2,6,7,8,9]],
 [[2,3,4,5,6],[2,7,8,9,10]],
]
for ci,blocks in enumerate(cases):
 f=CNF();f.nv=base.nv;f.extend(base.clauses);nc=set()
 for b in blocks:
  for i,j in itertools.product(range(5),repeat=2):
   if i!=j:f.append([v(b[i],b[j],b[t[i][j]])]);nc.add(tuple(sorted([b[i],b[j]])))
 for x,y in itertools.combinations(range(n),2):
  if (x,y) in nc:continue
  for z in range(n):f.extend([[-v(x,y,z),v(y,x,z)],[v(x,y,z),-v(y,x,z)]])
 name=f'twoblocks13-{ci}';f.to_file(out/(name+'.cnf'));start=time.time()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t','120',str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
 print(name,r.returncode,round(time.time()-start,3),flush=True)
 if r.returncode==10:
  vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
  spec['table']=[[None if same_hole(owner,x,y) else next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
  check(spec);(out/(name+'.json')).write_text(json.dumps(spec));print('PARTIAL MODEL VERIFIED',flush=True);break
