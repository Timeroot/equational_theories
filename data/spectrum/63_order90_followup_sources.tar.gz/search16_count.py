import sys,json,time,subprocess,itertools
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_exhaustive import base_cnf,variable,add_commuting_triangles,add_commuting_cycles_mod_three
from spectrum_63_bennett import prime
from spectrum_63_atp import validate
out=Path('/tmp/e63-order90-20260925');n=16;f=base_cnf(n);p=prime(5);v=lambda x,y,z:variable(n,x,y,z)
for x,y in itertools.product(range(5),repeat=2):f.append([v(x,y,p[x][y])])
add_commuting_triangles(f,n);add_commuting_cycles_mod_three(f,n)
offset=5
for k in [1,1,3,3,3]:
 for i in range(k):f.append([v(0,offset+i,offset+(i+1)%k)])
 offset+=k
from pysat.card import CardEnc,EncType
nc={}
for x,y in itertools.combinations(range(n),2):
 f.nv+=1;u=f.nv;nc[x,y]=nc[y,x]=u
 for z in range(n):f.extend([[-v(x,y,z),-v(y,x,z),-u],[u,-v(x,y,z),v(y,x,z)]])
def exact_when(sel,bits,k):
 enc=CardEnc.equals(bits,k,top_id=f.nv,encoding=EncType.seqcounter)
 f.nv=max(f.nv,enc.nv);f.extend([[-sel,*cl] for cl in enc.clauses])
for x in range(5,16):
 cases=[(0,0),(1,1),(2,0),(2,1),(3,0),(3,1),(4,0),(4,1),(5,0)]
 sels=list(range(f.nv+1,f.nv+1+len(cases)));f.nv+=len(cases);f.append(sels)
 for a,b in itertools.combinations(sels,2):f.append([-a,-b])
 for (k,eps),sel in zip(cases,sels):
  exact_when(sel,[nc[x,p] for p in range(5)],k)
  exact_when(sel,[nc[x,y] for y in range(5,16) if y!=x],2*k+eps)
  exact_when(sel,[v(x,y,y) for y in range(16)],1-eps)
name='count16-sub5';f.to_file(out/(name+'.cnf'));start=time.time()
with (out/(name+'.log')).open('w') as log:r=subprocess.run(['cadical','-t','900',str(out/(name+'.cnf'))],stdout=log,stderr=subprocess.STDOUT)
print(name,'exit',r.returncode,'seconds',time.time()-start,flush=True)
if r.returncode==10:
 vals={int(v) for line in (out/(name+'.log')).read_text().splitlines() if line.startswith('v ') for v in line.split()[1:] if int(v)>0}
 t=[[next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
 validate(t,n,229);(out/(name+'.json')).write_text(json.dumps(t));print('MODEL VERIFIED',flush=True)
