import sys,json,itertools,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import prime,gf_affine,product
from spectrum_63_atp import validate
out=Path('/tmp/e63-order90-20260925')
if (out/'design29-selected.json').exists():
 d=json.loads((out/'design29-orbits.json').read_text());ix=json.loads((out/'design29-selected.json').read_text());d={'groups':d['groups'],'blocks':[b for i in ix for b in d['orbits'][i]]}
else:d=json.loads((out/'gdd29.json').read_text())
groups,blocks=d['groups'],d['blocks'];owner={x:i for i,g in enumerate(groups) for x in g}
needed={p for p in itertools.combinations(range(29),2) if owner[p[0]]!=owner[p[1]]}
covered=[tuple(sorted(p)) for b in blocks for p in itertools.combinations(b,2)]
assert set(covered)==needed and len(covered)==len(needed)
small={3:prime(3,False),4:gf_affine(4,7,2,2),5:prime(5),7:prime(7),8:gf_affine(8,11,4,5)}
f12=product(small[4],small[3]);f9=product(small[3],small[3]);table=[[-1]*90 for _ in range(90)]
for gi,g in enumerate(groups):
 fill=f12 if gi<9 else f9;mp=list(range(3))+[3+3*x+i for x in g for i in range(3)]
 for a,x in enumerate(mp):
  for b,y in enumerate(mp):
   if a<3 and b<3 and gi<9:continue
   assert table[x][y]==-1;table[x][y]=mp[fill[a][b]]
for b in blocks:
 f=small[len(b)];assert all(f[i][i]==i for i in range(len(b)))
 for i,x in enumerate(b):
  for j,y in enumerate(b):
   if x==y:continue
   z=b[f[i][j]]
   for a,c in itertools.product(range(3),repeat=2):
    X,Y=3+3*x+a,3+3*y+c;assert table[X][Y]==-1;table[X][Y]=3+3*z+small[3][a][c]
validate(table,90,229);e63=[[row.index(y) for y in range(90)] for row in table];validate(e63,90,63)
(out/'model90.json').write_text(json.dumps({'design':d,'e229_table':table,'e63_table':e63,'sha256':hashlib.sha256(json.dumps(e63,separators=(',',':')).encode()).hexdigest()}))
print('VERIFIED MODEL90',flush=True)
