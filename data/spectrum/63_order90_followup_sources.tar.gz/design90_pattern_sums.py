from ortools.sat.python import cp_model
from itertools import combinations
import json,sys,time
from pathlib import Path
out=Path('/tmp/e63-order90-20260925');m=cp_model.CpModel();q=11
# Seven complements of lines in the Fano plane on nonzero vectors of F_2^3.
lines=[{a,b,a^b} for a,b in combinations(range(1,8),2)];lines=sorted(set(tuple(sorted(l)) for l in lines))
supports=[[i for i in range(7) if i+1 not in line]+[7] for line in lines]
pattern=sys.argv[1] if len(sys.argv)>1 else 'B'
rows=[]
if pattern=='B':
 supports2=[list(range(8))]+[[i for i in range(8) if i!=r] for r in range(7)]+supports+ [list(range(7)) for _ in range(3)]
else:
 supports2=[list(range(8)) for _ in range(3)]+supports+supports+ [list(range(7)) for _ in range(4)]
for r,sup in enumerate(supports2):
 anchor=7 if 7 in sup else sup[0]
 rows.append([None if i not in sup else 0 if r==0 or i==anchor else m.new_int_var(0,10,f'a_{r}_{i}') for i in range(8)])
for i,j in combinations(range(8),2):
 ds=[]
 for r,row in enumerate(rows):
  if row[i] is None or row[j] is None:continue
  d=m.new_int_var(0,10,f'd_{r}_{i}_{j}');m.add_modulo_equality(d,row[i]-row[j]+11,11);ds.append(d)
 assert len(ds)==11,(i,j,len(ds));m.add_all_different(ds);m.add(sum(ds)==55)
s=cp_model.CpSolver();s.parameters.max_time_in_seconds=180;s.parameters.num_search_workers=2;s.parameters.random_seed=90
s.parameters.log_search_progress=True
status=s.solve(m);print('RESULT',s.status_name(status),flush=True)
if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
 array=[[None if x is None else x if isinstance(x,int) else s.value(x) for x in row] for row in rows]
 groups=[list(range(11*i,11*(i+1))) for i in range(7)]+[list(range(77,90))]
 blocks=[]
 for r,row in enumerate(array):
  for k in range(11):
   b=[11*i+(a+k)%11 for i,a in enumerate(row) if a is not None]
   if r>=len(array)-2:b.append(88+r-(len(array)-2))
   blocks.append(b)
 owner={x:i for i,g in enumerate(groups) for x in g}
 needed={p for p in combinations(range(90),2) if owner[p[0]]!=owner[p[1]]}
 covered=[tuple(sorted(p)) for b in blocks for p in combinations(b,2)]
 assert set(covered)==needed and len(covered)==len(needed)
 (out/'gdd90.json').write_text(json.dumps({'groups':groups,'blocks':blocks,'matrix':array},indent=2))
 print('VERIFIED DESIGN 90',flush=True)
