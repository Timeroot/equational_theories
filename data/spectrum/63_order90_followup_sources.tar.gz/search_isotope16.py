from ortools.sat.python import cp_model
from pathlib import Path
import json,sys,time
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_atp import validate
out=Path('/tmp/e63-order90-20260925');data=json.loads((out/'singular16-subsquares.json').read_text());old=data['table'];n=16
for ci,(I,J,K) in enumerate(data['subsquares']):
 m=cp_model.CpModel();G=[];H=[]
 for y in range(n):
  G.append(m.new_int_var_from_domain(cp_model.Domain.from_values(J if y in I else [x for x in range(n) if x not in J]),f'g{y}'))
  H.append(m.new_int_var_from_domain(cp_model.Domain.from_values(K if y in I else [x for x in range(n) if x not in K]),f'h{y}'))
 m.add_all_different(G);m.add_all_different(H)
 T=[[m.new_int_var_from_domain(cp_model.Domain.from_values(I if x in I and y in I else list(range(n))),f't{x}_{y}') for y in range(n)] for x in range(n)]
 for x in range(n):
  m.add_all_different(T[x]);m.add_all_different([T[y][x] for y in range(n)])
  for y in range(n):
   z=m.new_int_var(0,n-1,f'z{x}_{y}');m.add_element(G[y],old[x],z);m.add_element(T[x][y],H,z)
 for y in range(n):
  for x in range(n):
   b=m.new_int_var(0,n-1,f'b{x}_{y}');m.add_element(T[y][x],T[y],b);m.add_element(b,[T[z][y] for z in range(n)],x)
 s=cp_model.CpSolver();s.parameters.max_time_in_seconds=300;s.parameters.num_search_workers=2
 status=s.solve(m);print(ci,s.status_name(status),flush=True)
 if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
  table=[[s.value(z) for z in row] for row in T];validate(table,n,229)
  assert all(table[x][y] in I for x in I for y in I)
  (out/'model16-isotope.json').write_text(json.dumps({'table':table,'submodel':I,'G':[s.value(z) for z in G],'H':[s.value(z) for z in H]}));print('VERIFIED MODEL',flush=True);break
