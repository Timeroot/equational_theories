fof(law,axiom, ![X,Y,Z]: X=m(m(Y,X),m(X,m(Y,Z)))).
fof(dual,axiom, ![X,Y,Z]: m(m(m(Z,Y),X),m(X,Y))=X).
fof(left_regular,axiom, ![X,Y]: m(X,m(m(X,Y),X))=m(X,Y)).
fof(right_regular,axiom, ![X,Y]: m(m(X,m(Y,X)),X)=m(Y,X)).
fof(absorb,axiom, ![W,X,Y,Z]: m(X,m(m(X,m(Y,Z)),m(m(Y,X),W)))=m(X,m(Y,Z))).
fof(p,axiom, ![A,B,T]: p(A,B,T)=m(A,m(T,B))).
fof(goal,conjecture, ![A,B,T]: p(A,B,p(A,B,T))=p(A,B,T)).
