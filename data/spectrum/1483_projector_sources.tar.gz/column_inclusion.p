fof(law,axiom, ![X,Y,Z]: X=m(m(Y,X),m(X,m(Y,Z)))).
fof(dual,axiom, ![X,Y,Z]: m(m(m(Z,Y),X),m(X,Y))=X).
fof(left_regular,axiom, ![X,Y]: m(X,m(m(X,Y),X))=m(X,Y)).
fof(right_regular,axiom, ![X,Y]: m(m(X,m(Y,X)),X)=m(Y,X)).
fof(goal,conjecture, ![A,T,B,Z]: m(m(m(A,T),m(Z,m(A,m(m(A,T),B)))),m(A,T))=m(Z,m(A,m(m(A,T),B)))).
