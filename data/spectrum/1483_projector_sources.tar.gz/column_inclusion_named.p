fof(law,axiom, ![X,Y,Z]: X=m(m(Y,X),m(X,m(Y,Z)))).
fof(dual,axiom, ![X,Y,Z]: m(m(m(Z,Y),X),m(X,Y))=X).
fof(left_regular,axiom, ![X,Y]: m(X,m(m(X,Y),X))=m(X,Y)).
fof(right_regular,axiom, ![X,Y]: m(m(X,m(Y,X)),X)=m(Y,X)).
fof(u_def,axiom,u=m(a,t)).
fof(v_def,axiom,v=m(a,m(u,b))).
fof(goal,conjecture,m(m(u,m(z,v)),u)=m(z,v)).
