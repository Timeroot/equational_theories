import sys,itertools,json,time
from pysat.card import CardEnc,EncType
from pysat.formula import IDPool
from pysat.solvers import Solver
n,rank=map(int,sys.argv[1:3]);start=time.time()
pool=IDPool();solver=Solver(name='cadical195');rng=range(n)
def add(c):solver.add_clause(c)
def exactly(v):
 for c in CardEnc.equals(v,1,vpool=pool,encoding=EncType.seqcounter):add(c)
p=lambda x,y,z:pool.id(('p',x,y,z));row=lambda x,z:pool.id(('row',x,z));col=lambda x,z:pool.id(('col',x,z));good=lambda x,y,z:pool.id(('good',x,y,z));dual=lambda x,y,z:pool.id(('dual',x,y,z))
for x,y in itertools.product(rng,repeat=2):exactly([p(x,y,z)for z in rng])
for y,z,b in itertools.product(rng,repeat=3):add([-p(y,z,b),row(y,b)]);add([-p(z,y,b),col(y,b)])
for y,b in itertools.product(rng,repeat=2):add([-row(y,b)]+[p(y,z,b)for z in rng]);add([-col(y,b)]+[p(z,y,b)for z in rng])
for x,b,c,d in itertools.product(rng,repeat=4):add([-good(x,b,c),-p(x,c,d),p(b,d,x)]);add([-dual(x,b,c),-p(c,x,d),p(d,b,x)])
for x,y,b,c in itertools.product(rng,repeat=4):add([-p(y,x,b),-row(y,c),good(x,b,c)]);add([-p(x,y,b),-col(y,c),dual(x,b,c)])
for x,b,c in itertools.product(rng,repeat=3):add([-col(x,b),-p(x,b,c),p(c,x,b)]);add([-row(x,b),-p(b,x,c),p(x,c,b)])

for x in rng:
 for im in (row,col):
  for c in CardEnc.equals([im(x,z)for z in rng],rank,vpool=pool,encoding=EncType.seqcounter):add(c)
add([p(0,0,0),p(0,0,1)])
print('encoded',n,rank,pool.top,solver.nof_clauses(),time.time()-start,flush=True)
ok=solver.solve();print('SAT'if ok else'UNSAT',time.time()-start,flush=True)
if ok:
 m=set(solver.get_model());table=[[next(z for z in rng if p(x,y,z)in m)for y in rng]for x in rng]
 assert all(table[table[y][x]][table[x][table[y][z]]]==x for x,y,z in itertools.product(rng,repeat=3))
 assert all(len(set(r))==rank for r in table)
 record={'order':n,'rank':rank,'table':table,'central':all(table[table[y][x]][table[x][z]]==x for x,y,z in itertools.product(rng,repeat=3))}
 json.dump(record,open(f'/tmp/e1483-projectors-20260926/uniform-{n}-{rank}.json','w'),indent=2);print(record,flush=True)
