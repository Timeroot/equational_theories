fof(law,axiom, ![X,Y,Z]: X=m(m(Y,X),m(X,m(Y,Z)))).
fof(dual,axiom, ![X,Y,Z]: m(m(m(Z,Y),X),m(X,Y))=X).
fof(left_regular,axiom, ![X,Y]: m(X,m(m(X,Y),X))=m(X,Y)).
fof(right_regular,axiom, ![X,Y]: m(m(X,m(Y,X)),X)=m(Y,X)).
fof(fix,axiom, m(a,m(t,b))=t).
fof(goal,conjecture,m(a,m(m(a,m(t,c)),b))=m(a,m(t,c))).
