import argparse,itertools,json,time
from pysat.card import CardEnc,EncType
from pysat.formula import IDPool
from pysat.solvers import Solver
p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('goal',choices=['idem','preserve','commute','not1485','not168']);p.add_argument('--b',type=int);p.add_argument('--t',type=int);a=p.parse_args();n=a.n;start=time.time()
pool=IDPool();solver=Solver(name='cadical195');rng=range(n)
def add(c):solver.add_clause(c)
def exactly(v):
 for c in CardEnc.equals(v,1,vpool=pool,encoding=EncType.seqcounter):add(c)
p=lambda x,y,z:pool.id(('p',x,y,z));row=lambda x,z:pool.id(('row',x,z));col=lambda x,z:pool.id(('col',x,z));good=lambda x,y,z:pool.id(('good',x,y,z));dual=lambda x,y,z:pool.id(('dual',x,y,z))
for x,y in itertools.product(rng,repeat=2):exactly([p(x,y,z)for z in rng])
for y,z,b in itertools.product(rng,repeat=3):add([-p(y,z,b),row(y,b)]);add([-p(z,y,b),col(y,b)])
for y,b in itertools.product(rng,repeat=2):add([-row(y,b)]+[p(y,z,b)for z in rng]);add([-col(y,b)]+[p(z,y,b)for z in rng])
for x,b,c,d in itertools.product(rng,repeat=4):add([-good(x,b,c),-p(x,c,d),p(b,d,x)]);add([-dual(x,b,c),-p(c,x,d),p(d,b,x)])
for x,y,b,c in itertools.product(rng,repeat=4):add([-p(y,x,b),-row(y,c),good(x,b,c)]);add([-p(x,y,b),-col(y,c),dual(x,b,c)])
for x,b,c in itertools.product(rng,repeat=3):add([-col(x,b),-p(x,b,c),p(c,x,b)]);add([-row(x,b),-p(b,x,c),p(x,c,b)])
# a=0 by relabeling. No other symmetry restriction is imposed.
cache={};counter=itertools.count()
def expr(t):
 if t in cache:return cache[t]
 v=[pool.id(('term',t,k))for k in rng];exactly(v);cache[t]=v
 if isinstance(t,int):add([v[t]])
 elif isinstance(t,tuple):
  l,r=map(expr,t)
  for i,j,k in itertools.product(rng,repeat=3):add([-l[i],-r[j],-p(i,j,k),v[k]])
 return v
if a.goal in ('not1485','not168'):
 for x in rng:
  for c in CardEnc.atleast([row(x,z) for z in rng],2,vpool=pool,encoding=EncType.seqcounter):add(c)
  if a.goal=='not168':add([-row(x,z)for z in rng])
 truth=pool.id('truth');add([truth]);seen=lambda i,z:pool.id(('seen',i,z))if i>=0 else-truth
 for i in rng:
  for z in range(1,n):
   old,new,value=seen(i-1,z),seen(i,z),p(0,i,z)
   add([-old,new]);add([-value,new]);add([-new,old,value])
   if z>max(1,i+1):add([-value,seen(i-1,z-1)])
P=lambda b,t:(0,(t,b))
if a.goal=='idem':lhs=P('b',P('b','t'));rhs=P('b','t')
elif a.goal=='preserve':lhs=P('b',P('c',P('b','t')));rhs=P('c',P('b','t'))
elif a.goal=='commute':lhs=P('b',P('c','t'));rhs=P('c',P('b','t'))
elif a.goal=='not1485':lhs=(('b',0),(0,('t','b')));rhs=0
else:lhs=(('b',0),(0,'t'));rhs=0
l,r=expr(lhs),expr(rhs)
if a.b is not None:add([expr('b')[a.b]])
if a.t is not None:add([expr('t')[a.t]])
for k in rng:add([-l[k],-r[k]])
print('encoded',n,a.goal,pool.top,solver.nof_clauses(),time.time()-start,flush=True)
ok=solver.solve();print('SAT'if ok else'UNSAT',time.time()-start,flush=True)
if ok:
 m=set(solver.get_model());tab=[[next(z for z in rng if p(x,y,z)in m)for y in rng]for x in rng]
 assert all(tab[tab[y][x]][tab[x][tab[y][z]]]==x for x,y,z in itertools.product(rng,repeat=3))
 val=lambda t:next(k for k,v in enumerate(cache[t])if v in m)
 record={'order':n,'goal':a.goal,'table':tab,'a':0,'assignment':{t:val(t)for t in cache if isinstance(t,str)},'lhs':val(lhs),'rhs':val(rhs)}
 assert record['lhs']!=record['rhs'];json.dump(record,open(f'/tmp/e1483-projectors-20260926/counter-{n}-{a.goal}-b{a.b}-t{a.t}.json','w'),indent=2);print(record,flush=True)
