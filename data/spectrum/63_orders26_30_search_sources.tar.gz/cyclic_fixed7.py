import itertools,json,sys
from pathlib import Path
sys.path.insert(0,'scripts')
from spectrum_63_atp import validate
from spectrum_63_bennett import prime
q=23;p=7;root=Path('/tmp/e63-26-30-20260924');stats={'sign_patterns':0,'initial_shifts':0,'consistent_maps':0,'latin_maps':0,'models':0};latins=[]
for signs in itertools.product([1,-1],repeat=6):
 A=[1]+[s*pow(2,i+1,q)%q for i,s in enumerate(signs)];U=set(A)|{2*a%q for a in A}|{-2*a%q for a in A};D=set(range(1,q))-U
 assert len(U)==15 and len(D)==7
 stats['sign_patterns']+=1
 for d0 in sorted(D):
  stats['initial_shifts']+=1;ds=[d0]
  for i in range(1,7):ds.append((ds[-1]+A[i])%q if A[i]==2*A[i-1]%q else -ds[-1]%q)
  if set(ds)!=D:continue
  f={0:0};okay=True
  for a,d in zip(A,ds):
   for x,y in [(a,d),(-2*a%q,-d%q),(2*a%q,(d+2*a)%q)]:
    if x in f and f[x]!=y:okay=False
    f[x]=y
  if not okay:continue
  stats['consistent_maps']+=1
  if set(f)!=set(range(q))-D or set(f.values())!=set(range(q))-{-2*a%q for a in A} or {(f[x]-x)%q for x in f}!=set(range(q))-set(A):continue
  stats['latin_maps']+=1;latins.append({'A':A,'D_in_A_order':ds,'f':f})
  fixed={d:i for i,d in enumerate(ds)};inner=prime(7)
  def op(x,y):
   if x>=q and y>=q:return q+inner[x-q][y-q]
   if x>=q:return (y+A[x-q])%q
   if y>=q:return (x-2*A[y-q])%q
   d=(y-x)%q;return q+fixed[d] if d in D else (x+f[d])%q
  t=[[op(x,y) for y in range(q+p)] for x in range(q+p)]
  try:validate(t,30,229)
  except AssertionError:continue
  stats['models']+=1;e63=[[row.index(y) for y in range(30)] for row in t];validate(e63,30,63)
  (root/'order30-model.json').write_text(json.dumps({'status':'VERIFIED_MODEL_NOT_LEAN','method':'One orbit of length23 and seven fixed points','e229_table':t,'e63_table':e63,'A':A,'D':ds,'f':f},indent=2)+'\n')
print(stats,flush=True)
(root/'cyclic-fixed7.json').write_text(json.dumps({'status':'MODEL_FOUND' if stats['models'] else 'NO_MODEL_IN_THIS_AUTOMORPHISM_CLASS','counts':stats,'latin_candidates':latins},indent=2)+'\n')
