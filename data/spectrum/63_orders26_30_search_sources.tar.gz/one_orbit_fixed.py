import sys,time,json,subprocess,gzip,itertools,math
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from pysat.card import CardEnc,EncType
sys.path.insert(0,'scripts')
from spectrum_63_bennett import prime,gf_affine
from spectrum_63_atp import validate
q,p=int(sys.argv[1]),int(sys.argv[2]);n=q+p;root=Path('/tmp/e63-26-30-20260924');P=gf_affine(4,7,2,2) if p==4 else prime(p,False) if p>1 else [[0]]
units=[u for u in range(1,q) if math.gcd(u,q)==1]
def allowed(A):
 if q%2 and 0 in A:return False
 if q%2==0 and q//2 in A:return False
 B={2*a%q for a in A}
 if len(B)!=p or (B&{-b%q for b in B})-{0}:return False
 U=set(A)|B|{-b%q for b in B}
 return len(U|({0} if q%3 else set()))+p<=q
cases=sorted({min(tuple(sorted(a*u%q for a in A)) for u in units) for A in itertools.combinations(range(q),p) if allowed(A)})
print(q,p,'canonical shift sets',len(cases),flush=True)
(root/f'one-orbit-{q}-{p}-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
def run(it):
 index,A=it;name=f'one-orbit-{q}-{p}-{index}';clauses=[];top=q*n
 def lit(x,y,z):
  if x>=q:
   out=q+P[x-q][y-q] if y>=q else (y+A[x-q])%q
   return out==z
  if y>=q:return (x-2*A[y-q])%q==z
  return 1+(y-x)%q*n+((z-x)%q if z<q else z)
 def neg(v):return not v if type(v) is bool else -v
 def clause(vs):
  if any(v is True for v in vs):return
  clauses.append([v for v in vs if v is not False])
 def exactly(vs):
  nonlocal top
  fixed=sum(v is True for v in vs);vs=[v for v in vs if type(v) is int]
  if fixed>1:clauses.append([])
  elif fixed:clauses.extend([-v] for v in vs)
  else:
   c=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=c.nv;clauses.extend(c.clauses)
 for y in range(n):exactly([lit(0,y,z) for z in range(n)])
 for z in range(n):
  exactly([lit(0,y,z) for y in range(n)])
  exactly([lit(y,0,z) for y in range(n)])
 for x in range(n):
  for a in range(n):
   for b in range(n):clause([neg(lit(0,x,a)),neg(lit(0,a,b)),lit(b,0,x)])
 # The zero-shift and constant-square obstructions proved in the notes imply F(0) is finite.
 if q%3:
  for z in range(q,n):clause([neg(lit(0,0,z))])
 path=root/(name+'.cnf.gz');path.write_bytes(gzip.compress((f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses)).encode()));start=time.time()
 r=subprocess.run(['cadical','-t','5',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'order':n,'cycle_length':q,'fixed_points':p,'fixed_point_shifts':list(A),'status':'UNRESOLVED','seconds':time.time()-start}
 if r.returncode==20:d['status']='UNSAT_FIXED_AUTOMORPHISM_AND_SHIFTS'
 if r.returncode==10:
  vals={int(x) for line in out.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0}
  def true(v):return v if type(v) is bool else v in vals
  t=[[next(z for z in range(n) if true(lit(x,y,z))) for y in range(n)] for x in range(n)];validate(t,n,229);e63=[[row.index(y) for y in range(n)] for row in t];validate(e63,n,63);d.update(status='VERIFIED_MODEL_NOT_LEAN',e229_table=t,e63_table=e63)
 (root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(index,A,d['status'],round(d['seconds'],3),flush=True);return d
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(root/f'one-orbit-{q}-{p}-report.json').write_text(json.dumps(results,indent=2)+'\n')
