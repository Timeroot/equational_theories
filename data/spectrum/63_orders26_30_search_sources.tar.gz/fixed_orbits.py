import sys,json,time,subprocess,gzip
from pathlib import Path
from pysat.card import CardEnc,EncType
sys.path.insert(0,'scripts')
from spectrum_63_bennett import prime,gf_affine
from spectrum_63_atp import validate
q,k,p=map(int,sys.argv[1:4]);secs=int(sys.argv[4]) if len(sys.argv)>4 else 60;n=q*k+p;fixed=q*k;root=Path('/tmp/e63-26-30-20260924');name=f'fixed-orbits-{q}-{k}-{p}'
P={1:[[0]],3:prime(3,False),4:gf_affine(4,7,2,2),5:prime(5),7:prime(7),8:gf_affine(8,11,4,5)}[p]
# Normalize simultaneous cyclic shifts of all nonfixed labels.
def shift(x,a):return x if x>=fixed else x//q*q+(x%q+a)%q
keys={};clauses=[]
def lit(x,y,z):
 if x>=fixed and y>=fixed:return z==fixed+P[x-fixed][y-fixed]
 a=-(x%q if x<fixed else y%q);xx,yy,zz=shift(x,a),shift(y,a),shift(z,a);key=(xx,yy,zz)
 if key not in keys:keys[key]=len(keys)+1
 return keys[key]
# Assign all primary variables before auxiliaries.
for x in range(n):
 for y in range(n):
  for z in range(n):lit(x,y,z)
top=len(keys)
def neg(v):return not v if type(v) is bool else -v
def clause(vs):
 if any(v is True for v in vs):return
 clauses.append([v for v in vs if v is not False])
def exactly(vs):
 global top
 ntrue=sum(v is True for v in vs);vs=[v for v in vs if type(v) is int]
 if ntrue>1:clauses.append([])
 elif ntrue:clauses.extend([-v] for v in vs)
 else:
  c=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=c.nv;clauses.extend(c.clauses)
reps=list(range(0,fixed,q))+list(range(fixed,n))
for x in reps:
 for y in range(n):exactly([lit(x,y,z) for z in range(n)])
 for z in range(n):
  exactly([lit(x,y,z) for y in range(n)])
  exactly([lit(y,x,z) for y in range(n)])
for y in reps:
 for x in range(n):
  for a in range(n):
   for b in range(n):clause([neg(lit(y,x,a)),neg(lit(y,a,b)),lit(b,y,x)])
path=root/(name+'.cnf.gz');path.write_bytes(gzip.compress((f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses)).encode()));print(name,'primary variables',len(keys),'clauses',len(clauses),flush=True);start=time.time()
r=subprocess.run(['cadical','-t',str(secs),str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=secs+20);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'order':n,'cycle_length':q,'cycles':k,'fixed_points':p,'fixed_submodel':P,'status':'UNRESOLVED','seconds':time.time()-start}
if r.returncode==20:d['status']='UNSAT_SPECIFIED_AUTOMORPHISM_AND_FIXED_SUBMODEL'
if r.returncode==10:
 vals={int(x) for l in out.splitlines() if l.startswith('v ') for x in l.split()[1:] if int(x)>0}
 def true(v):return v if type(v) is bool else v in vals
 t=[[next(z for z in range(n) if true(lit(x,y,z))) for y in range(n)] for x in range(n)];validate(t,n,229);e63=[[row.index(y) for y in range(n)] for row in t];validate(e63,n,63);d.update(status='VERIFIED_MODEL_NOT_LEAN',e229_table=t,e63_table=e63)
(root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(d['status'],round(d['seconds'],2),flush=True)
