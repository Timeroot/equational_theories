import sys,json,subprocess,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'scripts')
from spectrum_63_bennett import prime
root=Path('/tmp/e63-26-30-20260924');q=prime(11);cycle=[1]
while q[0][cycle[-1]]!=1:cycle.append(q[0][cycle[-1]])
zs=[q[cycle[i]][cycle[(i-2)%5]] for i in range(5)];names=['e']+[f'a{i}' for i in range(5)]+[f'b{i}' for i in range(5)];values=[0]+cycle+zs;ix={v:names[i] for i,v in enumerate(values)}
axioms=['![X,Y]:m(m(Y,m(Y,X)),Y)=X','![X,Y]:m(Y,m(Y,m(X,Y)))=X','![X,Y]:m(Y,m(m(Y,X),Y))=X','![X]:m(X,X)=X','![X,Y,Z]:(m(X,Y)!=m(X,Z)|Y=Z)','![X,Y,Z]:(m(Y,X)!=m(Z,X)|Y=Z)']
axioms+=['m(e,e)=e']+[f'm(e,a{i})=a{(i+1)%5}' for i in range(5)]+[f'm(a{i},e)=a{(i-2)%5}' for i in range(5)]+[f'm(a{i},a{(i-2)%5})=b{i}' for i in range(5)]
axioms += [f'{names[i]}!={names[j]}' for i in range(6) for j in range(i)]
base='\n'.join(f'fof(a{i},axiom,({a})).' for i,a in enumerate(axioms))+'\n'
queries={'root_new':f'm(e,b0)={ix[q[0][zs[0]]]}','new_root':f'm(b0,e)={ix[q[zs[0]][0]]}','adjacent_old':f'm(a0,a1)={ix[q[cycle[0]][cycle[1]]]}','all_table':' & '.join(f'm({x},{y})={ix[q[values[i]][values[j]]]}' for i,x in enumerate(names) for j,y in enumerate(names))}
def run(item):
 name,query=item;path=root/f'five-cycle-{name}.p';path.write_text(base+f'fof(goal,conjecture,({query})).\n');start=time.time();r=subprocess.run(['/home/alex_harmonic_fun/defwork/bin/vampire','--mode','casc','--time_limit','30','--memory_limit','1024',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=40);out=r.stdout.decode();(root/f'five-cycle-{name}.log').write_text(out);print(name,[(s.strip()) for s in out.splitlines() if 'SZS status' in s],round(time.time()-start,1),flush=True)
with ThreadPoolExecutor(max_workers=4) as p:list(p.map(run,queries.items()))
