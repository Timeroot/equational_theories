import sys,json,math,time,subprocess,gzip
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from pysat.card import CardEnc,EncType
q=int(sys.argv[1]);n=2*q;root=Path('/tmp/e63-26-30-20260924');lines=(root/f'orbit-{q}-2-any.cnf').read_text().splitlines();head=lines[0].split();body='\n'.join(lines[1:])+'\n';top=int(head[2]);units=[u for u in range(q) if math.gcd(u,q)==1]
def canonical(s):
 best=s
 for u in units:
  for c in range(q):
   shifts=[0,c]
   for swap in [0,1]:
    t=[None,None]
    for i in range(2):
     j,a=divmod(s[i],q);t[i^swap]=(j^swap)*q+(u*a+shifts[j]-shifts[i])%q
    best=min(best,tuple(t))
 return best
cases=sorted({canonical((a,b)) for a in range(n) for b in range(n)})
def v(x,y,z):
 i,a=divmod(x,q);j,b=divmod(y,q);h,c=divmod(z,q)
 return 1+(((i*2+j)*q+(b-a)%q)*2+h)*q+(c-a)%q
extra=[]
# Sum of fixed-point counts across representative rows is exactly 2.
c=CardEnc.equals([v(y,x,x) for y in [0,q] for x in range(n)],2,top_id=top,encoding=EncType.seqcounter);top=c.nv;extra.extend(c.clauses)
for y in [0,q]:
 for a in range(n):
  for b in range(n):
   if a!=b:extra.append([-v(y,a,b),-v(y,b,a)])
   extra.extend([[-v(y,y,a),-v(y,a,b),v(a,y,b)],[-v(y,y,a),-v(a,y,b),v(y,a,b)]])
base=body+''.join(' '.join(map(str,c))+' 0\n' for c in extra);count=int(head[3])+len(extra)
(root/f'orbit-{q}-diagonal-cases.json').write_text(json.dumps(cases)+'\n');print(q,'diagonal classes',len(cases),flush=True)
def run(it):
 index,s=it;name=f'orbit-{q}-diagonal-{index}';path=root/(name+'.cnf.gz');rows=[[v(0,0,s[0])],[v(q,q,s[1])]];path.write_bytes(gzip.compress((f'p cnf {top} {count+2}\n'+base+''.join(' '.join(map(str,c))+' 0\n' for c in rows)).encode()));start=time.time()
 r=subprocess.run(['cadical','-t','15',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'order':n,'orbit_length':q,'orbits':2,'diagonal_representatives':list(s),'status':'UNRESOLVED','seconds':time.time()-start}
 if r.returncode==20:d['status']='UNSAT_FIXED_AUTOMORPHISM_AND_DIAGONAL'
 if r.returncode==10:
  vals={int(x) for line in out.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0};t=[[next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
  sys.path.insert(0,'scripts');from spectrum_63_atp import validate
  validate(t,n,229);e63=[[row.index(y) for y in range(n)] for row in t];validate(e63,n,63);d.update(status='VERIFIED_MODEL_NOT_LEAN',e229_table=t,e63_table=e63)
 (root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(q,index,s,d['status'],round(d['seconds'],2),flush=True);return d
with ThreadPoolExecutor(max_workers=4) as pool:result=list(pool.map(run,enumerate(cases)))
(root/f'orbit-{q}-diagonal-report.json').write_text(json.dumps(result,indent=2)+'\n')
