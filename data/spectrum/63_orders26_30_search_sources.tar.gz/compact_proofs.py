import sys,json,gzip,hashlib,subprocess,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'scripts')
from spectrum_63_partial import encode
r=Path('/tmp/e63-26-30-20260924');checked=r/'checked';out=r/'core';out.mkdir(exist_ok=True);regen=r/'regenerated';regen.mkdir(exist_ok=True)
families=[(25,1),(23,3),(22,4),(21,5),(29,1),(27,3),(26,4),(25,5)]
for q,p in families:
 with (r/f'regenerate-{q}-{p}.log').open('w') as f:subprocess.run(['python3','scripts/spectrum_63_cyclic.py',str(q),str(p),'--generate-only','--output',str(regen)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('regenerated',q,p,flush=True)
records=[d for d in json.loads((r/'cyclic-proofcheck.json').read_text())['cases'] if d['name'].startswith('one-orbit-')]+json.loads((r/'cyclic-proofcheck-extra.json').read_text())
for n in [6,8]:
 top,clauses=encode({'order':n,'hole_size':2,'outside_idempotent':False});data=(f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses)).encode();name=f'hole{n}-2';assert data==(r/name/'input.cnf').read_bytes();(regen/(name+'.cnf.gz')).write_bytes(gzip.compress(data));raw=(checked/(name+'.drat')).read_bytes();(checked/(name+'.drat.gz')).write_bytes(gzip.compress(raw));records.append({'name':name,'cnf_sha256':hashlib.sha256(data).hexdigest(),'proof_sha256':hashlib.sha256(raw).hexdigest()})
start=time.time()
def run(d):
 name=d['name'];data=gzip.decompress((regen/(name+'.cnf.gz')).read_bytes());raw=gzip.decompress((checked/(name+'.drat.gz')).read_bytes());assert hashlib.sha256(data).hexdigest()==d['cnf_sha256'];assert hashlib.sha256(raw).hexdigest()==d['proof_sha256']
 inp=out/(name+'.cnf');old=out/(name+'.old.drat');core=out/(name+'.drat');inp.write_bytes(data);old.write_bytes(raw)
 with (out/(name+'-trim.log')).open('w') as f:c=subprocess.run(['/tmp/e63-drat-trim/drat-trim',str(inp),str(old),'-l',str(core),'-C'],stdout=f,stderr=subprocess.STDOUT,timeout=30)
 assert c.returncode==0 and 'VERIFIED' in (out/(name+'-trim.log')).read_text()
 with (out/(name+'-check.log')).open('w') as f:c=subprocess.run(['/tmp/e63-drat-trim/drat-trim',str(inp),str(core)],stdout=f,stderr=subprocess.STDOUT,timeout=30)
 assert c.returncode==0 and 'VERIFIED' in (out/(name+'-check.log')).read_text()
 new=core.read_bytes();(out/(name+'.drat.gz')).write_bytes(gzip.compress(new));inp.unlink();old.unlink();core.unlink()
 return {'name':name,'status':'INDEPENDENTLY_CHECKED_UNSAT_NOT_LEAN','cnf_sha256':d['cnf_sha256'],'proof_sha256':hashlib.sha256(new).hexdigest(),'proof_bytes':len(new)}
res=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for d in pool.map(run,records):
  res.append(d)
  if len(res)%200==0:print('compacted and rechecked',len(res),'of',len(records),flush=True)
report={'status':'INDEPENDENTLY_CHECKED_RESTRICTED_UNSAT_NOT_LEAN','families':[{'cycle_length':q,'fixed_points':p,'case_count':len(json.loads((regen/f'one-orbit-{q}-{p}-cases.json').read_text()))} for q,p in families],'cyclic_cases':len(res)-2,'partial_cases':2,'seconds':time.time()-start,'cases':res}
(r/'compact-proofcheck.json').write_text(json.dumps(report,indent=2)+'\n');print('FINISHED',len(res),'compressed bytes',sum(x.stat().st_size for x in out.glob('*.drat.gz')),flush=True)
