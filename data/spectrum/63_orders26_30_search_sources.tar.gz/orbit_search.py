import sys,time,json,subprocess
from pathlib import Path
from pysat.card import CardEnc,EncType
q,k=int(sys.argv[1]),int(sys.argv[2]);mode=sys.argv[3] if len(sys.argv)>3 else 'any';secs=int(sys.argv[4]) if len(sys.argv)>4 else 60;n=q*k;root=Path('/tmp/e63-26-30-20260924');name=f'orbit-{q}-{k}-{mode}';clauses=[];top=k*k*q*n
# Automorphism: add 1 in the second coordinate of every cyclic orbit.
def v(x,y,z):
 i,a=divmod(x,q);j,b=divmod(y,q);h,c=divmod(z,q)
 return 1+(((i*k+j)*q+(b-a)%q)*k+h)*q+(c-a)%q
def exactly(vs):
 global top
 c=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=c.nv;clauses.extend(c.clauses)
for i in range(k):
 x=i*q
 for y in range(n):exactly([v(x,y,z) for z in range(n)])
 for z in range(n):
  exactly([v(x,y,z) for y in range(n)])
  exactly([v(y,x,z) for y in range(n)])
 if mode=='idem':clauses.append([v(x,x,x)])
 if mode=='nonidem':clauses.append([-v(x,x,x)])
for j in range(k):
 y=j*q
 for x in range(n):
  for a in range(n):
   for b in range(n):clauses.append([-v(y,x,a),-v(y,a,b),v(b,y,x)])
path=root/(name+'.cnf');path.write_text(f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses));start=time.time();print(name,'base cells',k*k*q,'vars',top,'clauses',len(clauses),flush=True)
r=subprocess.run(['cadical','-t',str(secs),str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=secs+15);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'order':n,'orbit_length':q,'orbits':k,'mode':mode,'status':'UNRESOLVED','seconds':time.time()-start}
if r.returncode==20:d['status']='UNSAT_FIXED_AUTOMORPHISM'
if r.returncode==10:
 vals={int(x) for line in out.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0};t=[[next(z for z in range(n) if v(x,y,z) in vals) for y in range(n)] for x in range(n)]
 sys.path.insert(0,'scripts');from spectrum_63_atp import validate
 validate(t,n,229);e63=[[row.index(y) for y in range(n)] for row in t];validate(e63,n,63)
 d.update(status='VERIFIED_MODEL_NOT_LEAN',e229_table=t,e63_table=e63)
(root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(d['status'],round(d['seconds'],3),flush=True)
