import sys,json,time,subprocess
from pathlib import Path
from pysat.card import CardEnc,EncType
q=int(sys.argv[1]);mode=sys.argv[2];root=Path('/tmp/e63-26-30-20260924');name=f'rotational-{q+1}-{mode}';hole=-3%q;omit=-2%q;clauses=[];top=q*q
v=lambda x,y:1+x*q+y
def exactly(vs):
 global top
 c=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=c.nv;clauses.extend(c.clauses)
for x in range(q):
 if x!=hole:exactly([v(x,y) for y in range(q) if y!=omit])
 for y in range(q):
  if x==hole or y==omit:clauses.append([-v(x,y)])
for y in range(q):
 if y!=omit:exactly([v(x,y) for x in range(q) if x!=hole])
for d in range(q):
 if d!=1:exactly([v(x,(x+d)%q) for x in range(q) if x!=hole])
 else:clauses.extend([-v(x,(x+d)%q)] for x in range(q) if x!=hole)
clauses.extend([[v(1,hole)],[v(2,-1%q)],[v(omit,3)]])
if mode=='idem':clauses.append([v(0,0)])
elif mode=='nonidem':clauses.append([-v(0,0)])
for x in range(q):
 if x==hole:continue
 for a in range(q):
  if a==omit:continue
  if a==hole:
   if x!=1:clauses.append([-v(x,a)])
   continue
  for b in range(q):
   if b==omit:continue
   y=-b%q;z=(x-b)%q
   c=[-v(x,a),-v(a,b)]
   if y!=hole and z!=omit:c.append(v(y,z))
   clauses.append(c)
path=root/(name+'.cnf');path.write_text(f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses));start=time.time()
print(name,'vars',top,'clauses',len(clauses),flush=True)
r=subprocess.run(['cadical','-t','60',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=75);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'order':q+1,'mode':mode,'status':'UNRESOLVED','seconds':time.time()-start}
if r.returncode==20:d['status']='UNSAT_CYCLIC_AUTOMORPHISM_RESTRICTION'
if r.returncode==10:
 vals={int(x) for line in out.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0};f=[q if x==hole else next(y for y in range(q) if v(x,y) in vals) for x in range(q)]
 def op(x,y):
  if x==q:return q if y==q else (y+1)%q
  if y==q:return (x+omit)%q
  z=f[(y-x)%q];return q if z==q else (x+z)%q
 t=[[op(x,y) for y in range(q+1)] for x in range(q+1)]
 sys.path.insert(0,'scripts');from spectrum_63_atp import validate
 validate(t,q+1,229);e63=[[row.index(y) for y in range(q+1)] for row in t];validate(e63,q+1,63)
 d.update(status='VERIFIED_MODEL_NOT_LEAN',permutation=f,e229_table=t,e63_table=e63)
(root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(d['status'],d['seconds'],flush=True)
