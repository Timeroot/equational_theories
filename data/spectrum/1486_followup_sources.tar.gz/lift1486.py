import json,itertools,time,sys
from pysat.formula import IDPool
from pysat.card import CardEnc,EncType
from pysat.solvers import Solver
w=json.load(open('data/spectrum/witnesses.json'))['1486:13'];T=[w[i*13:(i+1)*13]for i in range(13)];idem=[i for i in range(13)if T[i][i]==i]
chosen=int(sys.argv[1]);weights=[(4 if a==chosen else 1)if a in idem else 2 for a in range(13)]
pts=[(a,i)for a in range(13)for i in range(weights[a])];N=len(pts);assert N==26
pool=IDPool();S=Solver(name='cadical195');one=pool.id('true');S.add_clause([one]);start=time.time()
def add(c):
 if one in c:return
 S.add_clause([x for x in c if x!=-one])
p=lambda x,y,z:pool.id(('p',x,y,z))if T[pts[x][0]][pts[y][0]]==pts[z][0]else-one
sq=lambda z:pool.id(('s',z));col=lambda x,a:pool.id(('col',x,a));left=lambda x,b:pool.id(('left',x,b))
for x,y in itertools.product(range(N),repeat=2):
 outs=[p(x,y,z)for z in range(N)if p(x,y,z)!=-one]
 for c in CardEnc.equals(outs,1,vpool=pool,encoding=EncType.seqcounter):add(c)
for z,s in itertools.product(range(N),repeat=2):add([-p(z,z,s),sq(s)])
for s in range(N):add([-sq(s)]+[p(z,z,s)for z in range(N)])
for x,s,b in itertools.product(range(N),repeat=3):add([-sq(s),-p(x,s,b),left(x,b)])
for x,y,a in itertools.product(range(N),repeat=3):add([-p(y,x,a),col(x,a)])
for x,a,b in itertools.product(range(N),repeat=3):add([-left(x,b),-col(x,a),p(a,b,x)])
print(idem,chosen,N,pool.top,S.nof_clauses(),time.time()-start,flush=True)
r=S.solve();print(r,time.time()-start,flush=True)
if r:
 m=set(S.get_model());tab=[[next(z for z in range(N)if p(x,y,z)in m)for y in range(N)]for x in range(N)]
 assert all(tab[tab[y][x]][tab[x][tab[z][z]]]==x for x,y,z in itertools.product(range(N),repeat=3))
 json.dump({'order':N,'table':tab,'points':pts},open(f'/tmp/central-spectra-20260926/lift-{chosen}.json','w'))
