import json,itertools,time,sys
from pysat.formula import IDPool
from pysat.solvers import Solver
n=int(sys.argv[1]);w=json.load(open('data/spectrum/witnesses.json'))[f'1486:{n}'];T=[w[i*n:(i+1)*n]for i in range(n)]
pool=IDPool();S=Solver(name='cadical195');one=pool.id('true');S.add_clause([one]);start=time.time()
def add(cl):
 if one in cl:return
 S.add_clause([c for c in cl if c!=-one])
f=lambda a,b,i,j:pool.id(('f',a,b,i,j))
cache={}
def apply(a,b,u,v):
 if abs(u)==one and abs(v)==one:return f(a,b,int(u>0),int(v>0))
 key=(a,b,u,v)
 if key in cache:return cache[key]
 q=pool.id(('gate',)+key);cache[key]=q
 for i,j in itertools.product(range(2),repeat=2):
  cond=[-u if i else u,-v if j else v];z=f(a,b,i,j)
  add(cond+[-q,z]);add(cond+[q,-z])
 return q
for x,y,z,i,j,k in itertools.product(range(n),range(n),range(n),range(2),range(2),range(2)):
 a=apply(y,x,one if j else-one,one if i else-one)
 sq=apply(z,z,one if k else-one,one if k else-one)
 b=apply(x,T[z][z],one if i else-one,sq)
 c=apply(T[y][x],T[x][T[z][z]],a,b)
 add([c if i else-c])
print(n,'vars',pool.top,'clauses',S.nof_clauses(),time.time()-start,flush=True)
r=S.solve();print(r,time.time()-start,flush=True)
if r:
 m=set(S.get_model());tab=[[2*T[a][b]+int(f(a,b,i,j)in m)for b,j in itertools.product(range(n),range(2))]for a,i in itertools.product(range(n),range(2))]
 N=2*n
 assert all(tab[tab[y][x]][tab[x][tab[z][z]]]==x for x,y,z in itertools.product(range(N),repeat=3))
 json.dump({'order':N,'table':tab,'base':n},open(f'/tmp/central-spectra-20260926/double-{n}.json','w'))
