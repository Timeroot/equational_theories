E1483 bounded model searches, 26 September 2026.
The source files are exact copies of the executed scripts. They import repository Python helpers from scripts/ and PySAT/numpy. To reproduce the original paths, extract to /tmp/e1483-focus-20260926 and run from the repository with PYTHONPATH=scripts OPENBLAS_NUM_THREADS=1. The wrappers retain their original fixed time limits; their main blocks launch two workers. Do not interpret UNKNOWN as UNSAT.

rank_search.py 90: first pass.
refine12.py: 900 seconds per rank 2, 3, 4, 5.
split12rank2.py: 40 first-row profiles, 45 seconds each.
split12balanced.py: 4 balanced profiles with collision clauses, 300 seconds each.
split12rank3.py: 18 prefix cases with collision clauses, 120 seconds each.
