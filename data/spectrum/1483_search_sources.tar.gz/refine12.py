import sys,json,time,concurrent.futures,pathlib
sys.path.insert(0,'/tmp/e1483-focus-20260926')
from rank_search import search
P=pathlib.Path('/tmp/e1483-focus-20260926')
def run(k):
 t=time.monotonic();s,m=search(12,k,900,'cadical195','edges',True)
 d={'order':12,'minimum_rank':k,'status':s,'table':m,'seconds':time.monotonic()-t,'budget':900,'constraints':'edges','normalize_first_row':True,'solver':'cadical195','trust':'External search only; SAT tables independently checked.'}
 (P/f'order12-rank{k}-900s.json').write_text(json.dumps(d,indent=2)+'\n');return d
with concurrent.futures.ProcessPoolExecutor(2) as ex:
 for d in ex.map(run,[2,3,4,5]):print(json.dumps(d),flush=True)
