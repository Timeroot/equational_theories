import pathlib,subprocess,re,concurrent.futures,json,time
P=pathlib.Path('/tmp/e1483-focus-20260926')
base='''fof(law,axiom, ![X,Y,Z]: f(f(Y,X),f(X,f(Y,Z)))=X).
fof(dual,axiom, ![X,Y,Z]: f(f(f(Z,Y),X),f(X,Y))=X).
fof(lreg,axiom, ![X,Y]: f(X,f(f(X,Y),X))=f(X,Y)).
fof(rreg,axiom, ![X,Y]: f(f(X,f(Y,X)),X)=f(Y,X)).
fof(sharp,axiom, ![X]: f(a,f(b,X))=b).
'''
goals={
 'sharp_right_general':'![X]: f(f(X,a),b)=a',
 'sharp_rectangle_left':'![X,Y]: f(a,f(f(a,X),f(Y,b)))=f(a,X)',
 'sharp_rectangle_right':'![X,Y]: f(f(f(a,X),f(Y,b)),b)=f(Y,b)',
}
def run(item):
 name,goal=item;p=P/(name+'.p');p.write_text(base+f'fof(goal,conjecture, {goal}).\n');start=time.monotonic()
 with p.with_suffix('.log').open('w') as out:
  try:r=subprocess.run(['/home/alex_harmonic_fun/defwork/bin/twee','--max-term-size','40','--max-cp-depth','10',str(p)],stdout=out,stderr=subprocess.STDOUT,timeout=180);status=r.returncode
  except subprocess.TimeoutExpired:status='timeout'
 log=p.with_suffix('.log').read_text();d={'name':name,'status':status,'seconds':time.monotonic()-start,'szs':re.findall('SZS status (\\w+)',log)}
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
with concurrent.futures.ThreadPoolExecutor(2) as ex:list(ex.map(run,goals.items()))
