fof(law,axiom, ![X,Y,Z]: f(f(Y,X),f(X,f(Y,Z)))=X).
fof(dual,axiom, ![X,Y,Z]: f(f(f(Z,Y),X),f(X,Y))=X).
fof(lreg,axiom, ![X,Y]: f(X,f(f(X,Y),X))=f(X,Y)).
fof(rreg,axiom, ![X,Y]: f(f(X,f(Y,X)),X)=f(Y,X)).
fof(sharp,axiom, ![X]: f(a,f(b,X))=b).
fof(goal,conjecture, ![X]: f(f(X,a),b)=a).
