import sys,pathlib,json,time,concurrent.futures
sys.path.insert(0,'/tmp/e1483-focus-20260926')
from split12rank2 import search
P=pathlib.Path('/tmp/e1483-focus-20260926')
def run(job):
 a,b,c=job; row=[1,a,b]+[1]*c+[2]*(9-c);t=time.monotonic()
 status,table=search(12,2,300,'cadical195','collisions',True,row)
 d={'order':12,'minimum_rank':2,'first_row':row,'case':[a,b,c],'status':status,'table':table,'seconds':time.monotonic()-t,'budget':300,'constraints':'collisions','solver':'cadical195','trust':'External search only; SAT tables independently checked.'}
 (P/f'balanced12-rank2-{a}{b}-{c}.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(2) as ex:list(ex.map(run,[(1,1,3),(1,2,4),(2,1,4),(2,2,5)]))
