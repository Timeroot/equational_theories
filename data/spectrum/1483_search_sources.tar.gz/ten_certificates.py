import sys,inspect,itertools,json,pathlib,time,subprocess,concurrent.futures,os,gzip,hashlib
sys.path.insert(0,'scripts')
import definability_1483_sat_check as old
P=pathlib.Path('/tmp/e1483-focus-20260926')
s=inspect.getsource(old.cnf_clauses)
s=s.replace('assert (k, zero) in CASES','assert (k, zero) in [(2,False),(3,False)]+[(k,z) for k in range(4,10) for z in (False,True)]')
s=s.replace('n = 11','n = 10').replace('itertools.combinations(R, 8)','itertools.combinations(R, 7)')
s=s.replace('[3, 4, 6]','[3, 4, 5]').replace('[(3, 6), (4, 4), (6, 3)]','[(3, 5), (4, 4), (5, 3)]')
exec(s)
CADICAL='/home/alex_harmonic_fun/.elan/toolchains/leanprover--lean4---v4.29.1/bin/cadical'

def run(case):
 k,z=case;name=f'ten_rank{k}_zero{int(z)}';clauses=cnf_clauses(k,z)
 cnf=P/(name+'.cnf'); cnf.write_text(f'p cnf 10000 {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses))
 raw=P/(name+'.raw.lrat.gz');log=P/(name+'.solver.log');start=time.monotonic()
 rfd,wfd=os.pipe()
 with log.open('w') as out:
  proc=subprocess.Popen([CADICAL,'--quiet','--shrink=0','--lrat','--no-binary','-t','600',str(cnf),f'/dev/fd/{wfd}'],stdout=out,stderr=subprocess.STDOUT,pass_fds=(wfd,))
  os.close(wfd)
  with os.fdopen(rfd,'rb') as inp,gzip.open(raw,'wb',compresslevel=3) as dest:
   while chunk:=inp.read(1048576):
    dest.write(chunk)
    if raw.stat().st_size>100*1024**2:proc.terminate()
  rc=proc.wait()
 d={'order':10,'rank':k,'zero_in_image':z,'exit_code':rc,'seconds':time.monotonic()-start,'clauses':len(clauses),'cnf_sha256':hashlib.sha256(cnf.read_bytes()).hexdigest(),'raw_compressed_bytes':raw.stat().st_size}
 if rc==20:
  records={};last=None;base=len(clauses)
  with gzip.open(raw,'rt') as inp:
   for line in inp:
    words=line.split()
    if not words or words[1]=='d':continue
    row=list(map(int,words));idx=row[0];cut=row.index(0,1);lits=row[1:cut];hints=row[cut+1:-1]
    assert all(h>0 for h in hints)
    records[idx]=(lits,hints)
    if not lits:last=idx
  assert last is not None
  need={last};stack=[last]
  while stack:
   idx=stack.pop()
   for h in records[idx][1]:
    if h>base and h not in need:assert h in records;need.add(h);stack.append(h)
  chosen=sorted(need);mapping={idx:base+i+1 for i,idx in enumerate(chosen)}
  target=P/(name+'.lrat.gz');digest=hashlib.sha256();size=0
  with target.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,compresslevel=9) as out:
   for idx in chosen:
    lits,hints=records[idx];row=[mapping[idx],*lits,0,*[mapping.get(h,h) for h in hints],0]
    line=(' '.join(map(str,row))+'\n').encode();out.write(line);digest.update(line);size+=len(line)
  d.update(certificate=str(target),compressed_bytes=target.stat().st_size,proof_bytes=size,proof_steps=len(chosen),proof_sha256=digest.hexdigest(),compressed_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
  raw.unlink()
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return d

if __name__=='__main__':
 cases=[(2,False),(3,False)]+[(k,z) for k in range(4,10) for z in (False,True)]
 with concurrent.futures.ProcessPoolExecutor(2) as ex:list(ex.map(run,cases))
