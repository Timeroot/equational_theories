import equational_theories.Spectrum.Equation1483.TenSAT
open Spectrum.E1483.OrderTen.CNF

def main : IO Unit := do
  for k in [2:10] do
    for zero in [false, true] do
      if k ≤ 3 && zero then continue
      let F := natRankFormula 10 k zero
      let path := s!"/tmp/e1483-focus-20260926/ten_rank{k}_zero{if zero then 1 else 0}.lean.cnf"
      IO.FS.withFile path .write fun out => do
        out.putStrLn s!"p cnf 10000 {F.clauses.size}"
        for clause in F.clauses do
          out.putStrLn <| String.intercalate " "
            (clause.map (fun (v, b) => (if b then "" else "-") ++ toString (v+1))) ++ " 0"
