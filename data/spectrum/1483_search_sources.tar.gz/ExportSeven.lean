import equational_theories.Spectrum.Equation1483.SevenSAT
open Spectrum.E1483.OrderSeven.CNF

def main : IO Unit := do
  for k in [2:7] do
    for zero in [false, true] do
      if k ≤ 2 && zero then continue
      let F := natRankFormula 7 k zero
      let path := s!"/tmp/e1483-focus-20260926/seven_rank{k}_zero{if zero then 1 else 0}.lean.cnf"
      IO.FS.withFile path .write fun out => do
        out.putStrLn s!"p cnf 3773 {F.clauses.size}"
        for clause in F.clauses do
          out.putStrLn <| String.intercalate " "
            (clause.map (fun (v, b) => (if b then "" else "-") ++ toString (v+1))) ++ " 0"
