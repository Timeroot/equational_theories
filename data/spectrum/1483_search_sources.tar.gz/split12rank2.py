import sys,pathlib,itertools,inspect,json,time,concurrent.futures
sys.path.insert(0,'/tmp/e1483-focus-20260926')
import rank_search as rank
P=pathlib.Path('/tmp/e1483-focus-20260926')
s=inspect.getsource(rank.search)
s=s.replace('    normalize_first_row=False,\n','    normalize_first_row=False,\n    fixed_row=None,\n')
s=s.replace('    try:\n','    if fixed_row is not None:\n        for y, z in enumerate(fixed_row):\n            add([p(0, y, z)])\n    try:\n',1)
env=rank.__dict__.copy();exec(s,env);search=env['search']
def run(job):
 a,b,c=job;row=[1,a,b]+[1]*c+[2]*(9-c);t=time.monotonic()
 status,table=search(12,2,45,'cadical195','edges',True,row)
 d={'order':12,'minimum_rank':2,'first_row':row,'case':[a,b,c],'status':status,'table':table,'seconds':time.monotonic()-t,'budget':45}
 (P/f'split12-rank2-{a}{b}-{c}.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(2) as ex:list(ex.map(run,itertools.product((1,2),(1,2),range(10))))
