import sys,inspect,itertools,json,pathlib,time,subprocess,concurrent.futures,os,gzip,hashlib
sys.path.insert(0,'/tmp/e1483-focus-20260926')
from seven_search import cnf_clauses
import ten_certificates as ten
P=pathlib.Path('/tmp/e1483-focus-20260926')
CADICAL=ten.CADICAL
s=inspect.getsource(ten.run).replace("name=f'ten_rank", "name=f'seven_rank")
s=s.replace('p cnf 10000','p cnf 3773').replace("'order':10", "'order':7")
exec(s)
if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(2) as ex:list(ex.map(run,[(2,False)]+[(k,z)for k in range(3,7)for z in (False,True)]))
