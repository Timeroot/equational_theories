import sys,json,random,itertools,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_1483_constructions import extension_table
r=json.load(open('data/spectrum/1483_general_constructions.json'));rng=random.Random(14830930)
for q,trials in [(2,20),(3,10),(4,5),(5,3)]:
 for trial in range(trials):
  perms=[rng.sample(range(q),q) for _ in range(27)]
  raw=extension_table(r['extensions']['base'],perms);m=np.array(raw);n=len(m);xs=np.arange(n)
  P=m[:,m[xs[:,None],xs[None,:]]].transpose(0,2,1) # P[a,b,t]=m[a,m[t,b]]
  bad=np.argwhere(P[np.arange(n)[:,None,None],np.arange(n)[None,:,None],P]!=P)
  if len(bad):
   out=dict(kind='projector_idempotence',q=q,trial=trial,permutations=perms,witness=bad[0].tolist(),table=raw)
   Path('.cache/e1483-analysis/identity_counterexample.json').write_text(json.dumps(out)); print(out['kind'],q,trial,out['witness'],flush=True);sys.exit(0)
  # Check fixed-point preservation for all a,b,c and their fixed t (at most n^4).
  for a in range(n):
   for b in range(n):
    fixed=xs[P[a,b,:]==xs]
    for t in fixed:
     image=P[a,:,t]
     badc=xs[P[a,b,image]!=image]
     if len(badc):
      out=dict(kind='projector_preserves_fixed',q=q,trial=trial,permutations=perms,witness=[a,b,int(badc[0]),int(t)],table=raw)
      Path('.cache/e1483-analysis/identity_counterexample.json').write_text(json.dumps(out));print(out['kind'],q,trial,out['witness'],flush=True);sys.exit(0)
  print('passed',q,trial,flush=True)
