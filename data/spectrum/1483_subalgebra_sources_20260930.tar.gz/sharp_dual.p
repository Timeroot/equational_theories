fof(law,axiom, ![X,Y,Z]: f(f(Y,X),f(X,f(Y,Z)))=X).
fof(dual,axiom, ![X,Y,Z]: f(f(f(Z,Y),X),f(X,Y))=X).
fof(left_regular,axiom, ![X,Y]: f(X,f(f(X,Y),X))=f(X,Y)).
fof(right_regular,axiom, ![X,Y]: f(f(X,f(Y,X)),X)=f(Y,X)).
fof(row_edge,axiom, ![A,X]: e(A,f(A,X))).
fof(col_edge,axiom, ![A,X]: e(f(A,X),X)).
fof(edge_law,axiom, ![A,B,X]: (e(A,B) => f(f(A,X),f(X,B))=X)).
fof(sharp,axiom, ![X]: f(a,f(b,X))=b).
fof(goal,conjecture, ![X]: f(f(X,a),b)=a).
