fof(law,axiom, ![X,Y,Z]: f(f(Y,X),f(X,f(Y,Z)))=X).
fof(dual,axiom, ![X,Y,Z]: f(f(f(Z,Y),X),f(X,Y))=X).
fof(left_regular,axiom, ![X,Y]: f(X,f(f(X,Y),X))=f(X,Y)).
fof(right_regular,axiom, ![X,Y]: f(f(X,f(Y,X)),X)=f(Y,X)).
fof(row_edge,axiom, ![A,X]: e(A,f(A,X))).
fof(col_edge,axiom, ![A,X]: e(f(A,X),X)).
fof(edge_law,axiom, ![A,B,X]: (e(A,B) => f(f(A,X),f(X,B))=X)).
fof(path,axiom,e(e,a) & e(a,b)).
fof(t_def,axiom,f(e,b)=t).
fof(fixed,axiom,f(a,f(b,t))=b).
fof(goal,conjecture, a=t).
