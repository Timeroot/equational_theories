import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_1483_constructions import coefficient_components
m=json.load(open('data/spectrum/1483_general_constructions.json'))['extensions']['base']
colors={p:i+1 for i,c in enumerate(coefficient_components(m)) for p in c}
def reduce(word):
 s=[]
 for x in word:
  if s and s[-1]==-x:s.pop()
  else:s.append(x)
 return tuple(s)
def transform(c,coord):
 var,word=coord
 return (var,reduce((c,)+word))
def op(x,y):
 a,b=x[0],y[0]
 return(m[a][b],transform(-colors['B',a,b],x[2]),transform(colors['A',a,b],y[1]))
def var(i,v):return (v,((i,0),()),((i,1),()))
def P(a,b,t):return op(a,op(t,b))
def diag(x):return op(x,x)
results=[]
for name,nv,fn in [
 ('E1483',3,lambda x,y,z:(op(op(y,x),op(x,op(y,z))),x)),
 ('projector_idempotence',3,lambda a,b,t:(P(a,b,P(a,b,t)),P(a,b,t))),
 ('projector_fixed_preservation',4,lambda a,b,c,t:(P(a,b,P(a,c,P(a,b,t))),P(a,c,P(a,b,t)))),
 ('diagonal_cubic',1,lambda x:(diag(diag(diag(x))),diag(x)))]:
 count=0
 for bases in itertools.product(range(8),repeat=nv):
  l,r=fn(*(var(i,b) for i,b in enumerate(bases)));count+=1
  if l!=r:print('FAIL',name,bases,l,r);break
 else:
  print('PASS',name,count,flush=True)
  results.append(dict(identity=name,base_assignments=count,status='symbolic permutation-word identity'))
Path('.cache/e1483-analysis/symbolic.json').write_text(json.dumps(results,indent=2)+'\n')
