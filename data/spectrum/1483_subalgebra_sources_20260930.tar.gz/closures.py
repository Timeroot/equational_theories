import sys,json,time,random,collections,math
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_1483_constructions import extension_table

def closes(m,seed):
 s=list(seed); known=set(s); pos=0
 while pos<len(s):
  x=s[pos]; pos+=1
  for y in s[:]:
   for z in (m[x][y],m[y][x]):
    if z not in known: known.add(z);s.append(z)
 return frozenset(s)

def subalgebras(m,limit=10000):
 initial=frozenset(); seen={initial}; todo=[initial]
 for s in todo:
  for x in range(len(m)):
   if x not in s:
    t=closes(m,[*s,x])
    if t not in seen:
     seen.add(t);todo.append(t)
     if len(todo)>limit:return todo,False
 return todo,True

def cong(m,relations):
 n=len(m); p=list(range(n)); q=list(relations)
 def root(x):
  while p[x]!=x:p[x]=p[p[x]];x=p[x]
  return x
 while q:
  x,y=q.pop();x,y=root(x),root(y)
  if x==y:continue
  p[max(x,y)]=min(x,y)
  for z in range(n):q.append((m[x][z],m[y][z]));q.append((m[z][x],m[z][y]))
 return tuple(root(x) for x in range(n))

def congruences(m,limit=10000):
 n=len(m); principals={cong(m,[(x,y)]) for x in range(n) for y in range(x)}
 seen={tuple(range(n))};todo=list(seen)
 for a in todo:
  for b in principals:
   if all(a[x]==a[b[x]] for x in range(n)):continue
   c=cong(m,[(x,a[x]) for x in range(n)]+[(x,b[x]) for x in range(n)])
   if c not in seen:
    seen.add(c);todo.append(c)
    if len(todo)>limit:return todo,False
 return todo,True

def supported(n):return math.isqrt(n)**2==n or (n%2==0 and math.isqrt(n//2)**2==n//2)
def study(m,name):
 t=time.time(); subs,complete=subalgebras(m); profile=collections.Counter(map(len,subs));
 quot,cq=congruences(m); qp=collections.Counter(len(set(p)) for p in quot)
 ans=dict(name=name,order=len(m),subalgebras=dict(sorted(profile.items())),subalgebras_complete=complete,congruences=dict(sorted(qp.items())),congruences_complete=cq,seconds=round(time.time()-t,3))
 print(json.dumps(ans),flush=True)
 for s in subs:
  if s and not supported(len(s)): print('NEW SUBALGEBRA',name,len(s),sorted(s),flush=True)
 for c in quot:
  if not supported(len(set(c))):print('NEW QUOTIENT',name,len(set(c)),c,flush=True)
 return ans

r=json.load(open('data/spectrum/1483_general_constructions.json'));results=[]
for i,e in enumerate(r['extensions']['examples']):results.append(study(e['table'],f'saved32_{i}'))
rng=random.Random(14830930)
for q,trials in [(2,20),(3,10),(4,5)]:
 for i in range(trials):
  perms=[rng.sample(range(q),q) for _ in range(27)];m=extension_table(r['extensions']['base'],perms)
  results.append(study(m,f'random{8*q*q}_{i}'))
Path('.cache/e1483-analysis/closures.json').write_text(json.dumps(results,indent=2)+'\n')
