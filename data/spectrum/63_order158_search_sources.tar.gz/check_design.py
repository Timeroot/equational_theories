import sys,itertools,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import prime,gf_affine
from spectrum_63_atp import validate
p=Path(sys.argv[1]);d=json.loads(p.read_text());blocks=d if isinstance(d,list) else d['blocks'];seen=[[],[],[]]
for b in blocks:
 assert len(b) in [5,7,8] and len(set(map(tuple,b)))==len(b)
 for (i,x),(j,y) in itertools.combinations(b,2):
  assert i in [0,1] and j in [0,1] and 0<=x<79 and 0<=y<79
  if i==j:seen[i].append(min((x-y)%79,(y-x)%79))
  else:seen[2].append((x-y if i==0 else y-x)%79)
assert sorted(seen[0])==sorted(seen[1])==list(range(1,40))
assert sorted(seen[2])==list(range(79))
t=[[x if x==y else -1 for y in range(158)] for x in range(158)]
small={5:prime(5),7:prime(7),8:gf_affine(8,11,4,5)};pairs=set()
for b in blocks:
 f=small[len(b)];validate(f,len(b),229)
 for s in range(79):
  mp=[side*79+(x+s)%79 for side,x in b]
  for a,c in itertools.combinations(mp,2):
   pair=tuple(sorted([a,c]));assert pair not in pairs;pairs.add(pair)
  for i,x in enumerate(mp):
   for j,y in enumerate(mp):
    if x==y:assert mp[f[i][j]]==x
    else:assert t[x][y]==-1;t[x][y]=mp[f[i][j]]
assert len(pairs)==158*157//2
validate(t,158,229);e63=[[row.index(y) for y in range(158)] for row in t];validate(e63,158,63)
r={'law':63,'order':158,'status':'DIRECTLY_CHECKED_MODEL_NOT_LEAN','construction':'Cyclic block design on two copies of Z/79Z, filled with idempotent E229 models of orders 5,7,8, then rowwise left division','base_blocks':blocks,'e63_table':e63,'table_sha256':hashlib.sha256(json.dumps(e63,separators=(',',':')).encode()).hexdigest(),'source_search':str(p)}
Path('data/spectrum/63_order158_model.json').write_text(json.dumps(r,indent=2)+'\n');print('VERIFIED E63 ORDER 158',r['table_sha256'],flush=True)
