#include <bits/stdc++.h>
using namespace std;
int keys[3][79][79],target[53],h; atomic<int> best(999);
mutex mu;atomic<bool> found(false);
chrono::steady_clock::time_point deadline;
string dest;
struct Edge {int a,b,t;};
vector<Edge> edges;vector<int> inc[15];
void save(int sc,const array<int,15>& a,long long it,int seed){
 lock_guard<mutex> g(mu); if(sc>=best)return;best=sc;
 ofstream f(dest);f<<"{\"score\":"<<sc<<",\"h\":"<<h<<",\"iterations\":"<<it<<",\"seed\":"<<seed<<",\"positions\":[";
 for(int i=0;i<15;i++)f<<(i?",":"")<<a[i];f<<"]}\n";f.close();cerr<<"best "<<sc<<" seed "<<seed<<" iterations "<<it<<endl;
 if(sc==0)found=true;
}
void run(int seed){
 mt19937 rng(seed);array<int,15>a;int cnt[53];long long it=0;
 auto key=[&](int e){auto p=edges[e];return keys[p.t][a[p.a]][a[p.b]];};
 auto alter=[&](int k,int delta){int prev=max(0,cnt[k]-target[k]);cnt[k]+=delta;return max(0,cnt[k]-target[k])-prev;};
 while(!found && chrono::steady_clock::now()<deadline){
  memset(cnt,0,sizeof cnt);for(int&i:a)i=rng()%79;a[0]=a[7]=0;
  for(int e=0;e<(int)edges.size();e++)cnt[key(e)]++;
  int sc=0;for(int k=0;k<53;k++)sc+=max(0,cnt[k]-target[k]);
  for(int step=0;step<100000 && !found;step++,it++){
   if((step&4095)==0 && chrono::steady_clock::now()>deadline)return;
   int v;do{v=rng()%15;}while(v==0||v==7);
   int old=a[v],nv=rng()%79;if(nv==old)continue;
   int d=0;for(int e:inc[v])d+=alter(key(e),-1);a[v]=nv;for(int e:inc[v])d+=alter(key(e),1);
   double t=1.2*pow(.07/1.2, (step%25000)/25000.0);
   bool accept=d<=0 || generate_canonical<double,32>(rng)<exp(-d/t);
   if(accept){sc+=d;if(sc<best)save(sc,a,it,seed);}
   else {for(int e:inc[v])alter(key(e),-1);a[v]=old;for(int e:inc[v])alter(key(e),1);}
  }
 }
}
int main(int argc,char**argv){
 int seconds=argc>1?atoi(argv[1]):600,workers=argc>2?atoi(argv[2]):6;dest=argc>3?argv[3]:"/tmp/e63-158-20260924/symmetric-best.json";
 h=2;while(h*h%79*h%79!=1)h++;int hh=h*h%79;
 map<int,int>m[2];int cls[2][79];
 for(int t=0;t<2;t++)for(int d=1;d<79;d++){
  int rep=min({d,d*h%79,d*hh%79});if(t==0)rep=min(rep,min({79-d,79-d*h%79,79-d*hh%79}));
  if(!m[t].count(rep))m[t][rep]=m[t].size();cls[t][d]=m[t][rep];
 }
 assert(m[0].size()==13 && m[1].size()==26);
 for(int t=0;t<3;t++)for(int a=0;a<79;a++)for(int b=0;b<79;b++)keys[t][a][b]=a==b?52:(t==2?26+cls[1][(a-b+79)%79]:13*t+cls[0][(a-b+79)%79]);
 fill(target,target+52,1);target[52]=0;
 int sp[4]={0,1,h,hh};set<int>reserved;
 for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)reserved.insert(keys[0][sp[i]][sp[j]]);
 assert(reserved.size()==2);reserved.insert(keys[2][1][0]);for(int k:reserved)target[k]=0;
 for(int start:{0,7}){int end=start==0?7:15,as=start==0?2:5;
  for(int a=start;a<end;a++)for(int b=a+1;b<end;b++){
   int t=b<start+as?0:a>=start+as?1:2;
   inc[a].push_back(edges.size());inc[b].push_back(edges.size());edges.push_back({a,b,t});
  }
 }
 assert(edges.size()==49);deadline=chrono::steady_clock::now()+chrono::seconds(seconds);
 vector<thread>ts;for(int s=0;s<workers;s++)ts.emplace_back(run,18179+1237*s);for(auto&t:ts)t.join();
 cerr<<"finished best "<<best<<endl;
}
