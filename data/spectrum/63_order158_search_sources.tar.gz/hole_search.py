import json,sys,time,subprocess
from pathlib import Path
from itertools import product
from pysat.card import CardEnc,EncType
root=Path('/tmp/e63-158-20260924')
if '--nonidem' in sys.argv:
 root=root/'nonidem';root.mkdir(exist_ok=True)
def make(n,h):
 clauses=[];top=n**3
 def defined(x,y):return not(x<h and y<h)
 def var(x,y,z):return 1+(x*n+y)*n+z
 def exactly(v):
  nonlocal top
  c=CardEnc.equals(v,1,top_id=top,encoding=EncType.seqcounter);top=c.nv;clauses.extend(c.clauses)
 for x,y in product(range(n),repeat=2):
  if defined(x,y):
   zs=[z for z in range(n) if not((x<h and z<h) or (y<h and z<h))]
   exactly([var(x,y,z) for z in zs])
   for z in set(range(n))-set(zs):clauses.append([-var(x,y,z)])
  else:
   for z in range(n):clauses.append([-var(x,y,z)])
 for x in range(n):
  for z in range(n):
   if x<h and z<h:continue
   exactly([var(x,y,z) for y in range(n) if defined(x,y)])
   exactly([var(y,x,z) for y in range(n) if defined(y,x)])
 if "--nonidem" not in sys.argv:
  for x in range(h,n):clauses.append([var(x,x,x)])
 for x,y,a,b in product(range(n),repeat=4):
  if defined(x,y) and defined(y,a) and defined(b,y):clauses.append([-var(y,x,a),-var(y,a,b),var(b,y,x)])
 path=root/f'hole-{n}-{h}.cnf';path.write_text(f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses));return path
n,h=map(int,sys.argv[1:3]);path=make(n,h);start=time.time();r=subprocess.run(['/usr/local/bin/cadical','-t','300',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=320);out=r.stdout.decode();(root/f'hole-{n}-{h}.log').write_text(out)
d={'order':n,'hole_size':h,'status':'UNRESOLVED','seconds':time.time()-start}
if r.returncode==20:d['status']='UNSAT_RESTRICTED_NO_CERTIFICATE'
if r.returncode==10:
 vals={int(v) for l in out.splitlines() if l.startswith('v ') for v in l.split()[1:] if int(v)>0}
 t=[[None if x<h and y<h else next(z for z in range(n) if 1+(x*n+y)*n+z in vals) for y in range(n)] for x in range(n)]
 for x in range(n):
  expected=set(range(h,n)) if x<h else set(range(n))
  assert {z for z in t[x] if z is not None}==expected
  assert {t[y][x] for y in range(n) if t[y][x] is not None}==expected
 for x,y in product(range(n),repeat=2):
  if x<h and y<h:continue
  assert t[t[y][t[y][x]]][y]==x
 if "--nonidem" not in sys.argv:
  for x in range(h,n):assert t[x][x]==x
 d.update(status='VERIFIED_PARTIAL_MODEL',table=t)
(root/f'hole-{n}-{h}.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
