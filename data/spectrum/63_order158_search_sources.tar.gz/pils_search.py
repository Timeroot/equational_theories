import json,sys,time,subprocess
from pathlib import Path
from itertools import product
from pysat.card import CardEnc,EncType
from pysat.formula import CNF
from pysat.solvers import Solver
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import gf_affine,prime,product as direct_product
root=Path('/tmp/e63-158-20260924');sizes=list(map(int,sys.argv[1].split(',')));n=sum(sizes);owner=[i for i,s in enumerate(sizes) for _ in range(s)];name='pils-'+sys.argv[1].replace(',','-');start=time.time();clauses=[];top=n**3
var=lambda x,y,z:1+(x*n+y)*n+z
def exactly(vs):
 global top
 c=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);top=c.nv;clauses.extend(c.clauses)
for x,y in product(range(n),repeat=2):
 zs=[z for z in range(n) if owner[z] not in [owner[x],owner[y]]] if owner[x]!=owner[y] else []
 if zs:exactly([var(x,y,z) for z in zs])
 for z in set(range(n))-set(zs):clauses.append([-var(x,y,z)])
for x,z in product(range(n),repeat=2):
 if owner[x]==owner[z]:continue
 exactly([var(x,y,z) for y in range(n) if owner[x]!=owner[y]])
 exactly([var(y,x,z) for y in range(n) if owner[x]!=owner[y]])
for x,y,a,b in product(range(n),repeat=4):
 if owner[x]!=owner[y] and owner[a]!=owner[y] and owner[b]!=owner[y]:clauses.append([-var(y,x,a),-var(y,a,b),var(b,y,x)])
path=root/(name+('-phases' if '--phases' in sys.argv else '')+'.cnf');path.write_text(f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses))
if '--phases' in sys.argv:
 s=Solver(name='cadical195',bootstrap_with=clauses);base=direct_product(gf_affine(8,11,4,5),prime(3,False));assert n==23
 s.set_phases([(1 if base[x][y]==z else -1)*var(x,y,z) for x,y,z in product(range(n),repeat=3)])
 print('loaded phase solver',name,len(clauses),flush=True);r=s.solve();vals={v for v in s.get_model() if v>0} if r else None;status='UNSAT_RESTRICTED_NO_CERTIFICATE' if r is False else 'VERIFIED_PARTIAL_MODEL' if r else 'UNRESOLVED'
else:
 r=subprocess.run(['/usr/local/bin/cadical','-t','600',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=620);out=r.stdout.decode();(root/(name+'.log')).write_text(out)
 vals={int(v) for l in out.splitlines() if l.startswith('v ') for v in l.split()[1:] if int(v)>0} if r.returncode==10 else None;status='VERIFIED_PARTIAL_MODEL' if vals else 'UNSAT_RESTRICTED_NO_CERTIFICATE' if r.returncode==20 else 'UNRESOLVED'
d={'sizes':sizes,'status':status,'seconds':time.time()-start}
if vals:
 t=[[None if owner[x]==owner[y] else next(z for z in range(n) if var(x,y,z) in vals) for y in range(n)] for x in range(n)]
 for x in range(n):
  expected={z for z in range(n) if owner[z]!=owner[x]}
  assert {z for z in t[x] if z is not None}==expected
  assert {t[y][x] for y in range(n) if t[y][x] is not None}==expected
 for x,y in product(range(n),repeat=2):
  if owner[x]!=owner[y]:assert t[t[y][t[y][x]]][y]==x
 d['table']=t
(root/(name+('-phases' if '--phases' in sys.argv else '')+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(status,flush=True)
