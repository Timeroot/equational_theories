import json,gzip,time,subprocess,sys,concurrent.futures
from pathlib import Path
root=Path('/tmp/e63-158-20260924')
rows=[(15,4,[3,3,5],True),(15,4,[3,4,4],True),(15,4,[3,8],True),(15,4,[4,7],True),(15,4,[5,6],True),(15,4,[11],True),(25,6,[3,4,4,4,4],False),(34,3,[1]+[3]*10,False)]
def run(case):
 n,h,cs,idem=case;src=(root if idem else root/'nonidem')/f'hole-{n}-{h}.cnf';name=f'row-{n}-{h}-'+ '-'.join(map(str,cs));lines=src.read_text().splitlines();header=lines[0].split();clauses=[];perm={};offset=h
 for c in cs:
  for i in range(c):perm[offset+i]=offset+(i+1)%c
  offset+=c
 assert offset==n
 inv={v:k for k,v in perm.items()};var=lambda x,y,z:1+(x*n+y)*n+z
 for x in range(h,n):clauses.extend([[var(0,x,perm[x])],[var(x,0,inv[inv[x]])]])
 path=root/(name+'.cnf.gz');path.write_bytes(gzip.compress((f'p cnf {header[2]} {int(header[3])+len(clauses)}\n'+'\n'.join(lines[1:])+'\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses)).encode(),compresslevel=1));start=time.time()
 r=subprocess.run(['/usr/local/bin/cadical','-t','180',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=200);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'order':n,'hole_size':h,'cycles':cs,'outside_idempotent':idem,'status':'UNRESOLVED','seconds':time.time()-start}
 if r.returncode==20:d['status']='UNSAT_RESTRICTED_NO_CERTIFICATE'
 if r.returncode==10:
  vals={int(v) for l in out.splitlines() if l.startswith('v ') for v in l.split()[1:] if int(v)>0};t=[[None if x<h and y<h else next(z for z in range(n) if var(x,y,z) in vals) for y in range(n)] for x in range(n)]
  for x in range(n):
   want=set(range(h,n)) if x<h else set(range(n))
   assert {v for v in t[x] if v is not None}==want;assert {t[y][x] for y in range(n) if t[y][x] is not None}==want
  for x in range(n):
   for y in range(n):
    if not(x<h and y<h):assert t[t[y][t[y][x]]][y]==x
  if idem:assert all(t[x][x]==x for x in range(h,n))
  d.update(status='VERIFIED_PARTIAL_MODEL',table=t)
 (root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(name,d['status'],round(d['seconds'],2),flush=True)
 return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:res=list(p.map(run,rows))
(root/'row-hole-report.json').write_text(json.dumps(res,indent=2)+'\n')
