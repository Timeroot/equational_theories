import sys,json,itertools,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import prime,gf_affine,product,singular,td,glue
from spectrum_63_atp import validate
source=Path(sys.argv[1]);d=json.loads(source.read_text());assert d['status']=='VERIFIED_PARTIAL_MODEL';q=d['table'];n=len(q)
small={3:prime(3,False),4:gf_affine(4,7,2,2),5:prime(5),7:prime(7),8:gf_affine(8,11,4,5),11:prime(11),19:prime(19)}
if n==34 and d.get('hole_size')==3:
 for x in range(3):
  for y in range(3):q[x][y]=small[3][x][y]
 validate(q,34,229);t=singular(small[5],q,prime(31,False),p=3);method='Singular product 5*(34-3)+3 with a checked 34-model containing the 3-model'
elif n==25 and d.get('hole_size')==6:
 g,b=td(19,8);full25=product(small[5],small[5]);t=glue(g,b,6,[q]*7+[full25],small);method='Eight 19-point groups with a six-point common hole, filled by seven partial 25-models and a full 25-model'
elif n==23 and d.get('sizes')==[3]*7+[2]:
 groups,blocks=td(7,8);weights={x:3 for x in range(56)}
 for i,x in enumerate(groups[-1]):weights[x]=3 if i<3 else 2 if i==3 else 0
 pts=[(x,a) for x in range(56) for a in range(weights[x])];ix={p:i for i,p in enumerate(pts)};assert len(pts)==158;t=[[-1]*158 for _ in range(158)]
 model21=singular(small[5],small[5],small[4]);validate(model21,21,229)
 for gi,g in enumerate(groups):
  mp=[ix[x,a] for x in g for a in range(weights[x])];f=small[11] if gi==7 else model21;assert len(f)==len(mp)
  for i,x in enumerate(mp):
   for j,y in enumerate(mp):t[x][y]=mp[f[i][j]]
 for b in blocks:
  points=[(x,a) for x in b for a in range(weights[x])];own=[i for i,x in enumerate(b) for a in range(weights[x])]
  f=q if weights[b[-1]]==2 else product(small[7 if weights[b[-1]]==0 else 8],small[3]);assert len(f)==len(points)
  for i,(x,a) in enumerate(points):
   for j,(y,c) in enumerate(points):
    if own[i]==own[j]:continue
    out=f[i][j];assert out is not None and own[out] not in [own[i],own[j]];X,Y=ix[x,a],ix[y,c];assert t[X][Y]==-1;t[X][Y]=ix[points[out]]
 method='Truncate the threefold inflated TD(8,7) using a checked incomplete E229 table of type 3^7 2^1, then fill seven groups of size21 and one of size11'
else:raise ValueError('Not a completed ingredient for one of the three active constructions')
assert len(t)==158;validate(t,158,229);e63=[[row.index(y) for y in range(158)] for row in t];validate(e63,158,63)
r={'law':63,'order':158,'status':'DIRECTLY_CHECKED_MODEL_NOT_LEAN','construction':method,'ingredient':d,'e63_table':e63,'table_sha256':hashlib.sha256(json.dumps(e63,separators=(',',':')).encode()).hexdigest(),'source_search':str(source)}
Path('data/spectrum/63_order158_model.json').write_text(json.dumps(r,indent=2)+'\n');print('VERIFIED E63 ORDER 158',r['table_sha256'],flush=True)
