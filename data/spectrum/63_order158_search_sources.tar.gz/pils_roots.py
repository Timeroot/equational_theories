import sys,json,gzip,time,subprocess,concurrent.futures
from pathlib import Path
root=Path('/tmp/e63-158-20260924');sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import gf_affine
n=23;f=gf_affine(8,11,4,5);alpha={g:f[7][g] for g in range(7)};assert set(alpha.values())==set(range(7));src=root/'pils-3-3-3-3-3-3-3-2.cnf';lines=src.read_text().splitlines();head=lines[0].split();body='\n'.join(lines[1:])+'\n';owner=[i//3 for i in range(21)]+[7,7]
var=lambda x,y,z:1+(x*n+y)*n+z
def run(case):
 k,shift=case;name=f'pils-roots-{k}-{shift}';cs=[]
 for hole,powr,sh in [(21,1,0),(22,k,shift)]:
  perm={}
  for x in range(21):
   g,l=divmod(x,3)
   for _ in range(powr):g=alpha[g]
   perm[x]=3*g+(l+sh)%3
  inv={y:x for x,y in perm.items()}
  for x in range(21):cs.extend([[var(hole,x,perm[x])],[var(x,hole,inv[inv[x]])]])
 raw=(f'p cnf {head[2]} {int(head[3])+len(cs)}\n'+body+''.join(' '.join(map(str,c))+' 0\n' for c in cs)).encode();path=root/(name+'.cnf.gz');path.write_bytes(gzip.compress(raw,compresslevel=1));start=time.time()
 r=subprocess.run(['/usr/local/bin/cadical','-t','120',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=140);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'sizes':[3]*7+[2],'root_power':k,'label_shift':shift,'status':'UNRESOLVED','seconds':time.time()-start}
 if r.returncode==20:d['status']='UNSAT_RESTRICTED_NO_CERTIFICATE'
 if r.returncode==10:
  vals={int(v) for l in out.splitlines() if l.startswith('v ') for v in l.split()[1:] if int(v)>0};t=[[None if owner[x]==owner[y] else next(z for z in range(n) if var(x,y,z) in vals) for y in range(n)] for x in range(n)]
  for x in range(n):
   expected={z for z in range(n) if owner[z]!=owner[x]};assert {z for z in t[x] if z is not None}==expected;assert {t[y][x] for y in range(n) if t[y][x] is not None}==expected
  for x in range(n):
   for y in range(n):
    if owner[x]!=owner[y]:assert t[t[y][t[y][x]]][y]==x
  d.update(status='VERIFIED_PARTIAL_MODEL',table=t)
 (root/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(name,d['status'],d['seconds'],flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:results=list(p.map(run,[(k,s) for k in range(1,7) for s in range(2) if k!=1 or s!=0]))
(root/'pils-roots-report.json').write_text(json.dumps(results,indent=2)+'\n')
