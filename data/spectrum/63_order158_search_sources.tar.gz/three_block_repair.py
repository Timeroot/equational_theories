import json,itertools,time
from pathlib import Path
root=Path('/tmp/e63-158-20260924');seed=json.loads((root/'symmetric-best.json').read_text())['positions'];H=[1,23,55]
bs=[[(0,x) for x in [0]+H]+[(1,0)]]
for x,a in [(seed[:7],2),(seed[7:],5)]:
 for h in H:bs.append([(int(i>=a),v*h%79) for i,v in enumerate(x)])
def key(x,y):
 (s,a),(t,b)=x,y
 if s==t:return s*39+min((a-b)%79,(b-a)%79)-1 if a!=b else -1
 if s>t:a,b=b,a
 return 78+(a-b)%79
def mask(b):
 ks=[key(x,y) for x,y in itertools.combinations(b,2)]
 if -1 in ks or len(set(ks))!=len(ks):return None
 return sum(1<<k for k in ks)
fixed=bs[:1]+bs[4:];used=0
for b in fixed:
 m=mask(b);assert m is not None and not used&m;used|=m
# The three pairs in orbit A are fixed as well.
for b in bs[1:4]:
 m=mask(b[:2]);assert not used&m;used|=m
remaining=((1<<157)-1)^used;candidates=[]
for block in bs[1:4]:
 aa=block[:2];opts=[b for b in range(79) if all(key(a,(1,b))>=0 and remaining>>key(a,(1,b))&1 for a in aa)];rows=[]
 for subset in itertools.combinations(opts,5):
  b=aa+[(1,v) for v in subset];m=mask(b)
  if m is not None:
   m^=mask(aa)
   if m&remaining==m:rows.append((m,b))
 print('candidate points',len(opts),'valid blocks',len(rows),flush=True);candidates.append(rows)
lookup={m:b for m,b in candidates[2]}
for m,a in candidates[0]:
 for n,b in candidates[1]:
  if m&n:continue
  c=lookup.get(remaining^(m|n))
  if c is not None:
   result={'method':'three-block exact repair','blocks':[bs[0],a,b,c]+bs[4:],'status':'DESIGN_CANDIDATE'}
   (root/'three-block-repair.json').write_text(json.dumps(result,indent=2)+'\n');print('FOUND');raise SystemExit
print('No repair with the other four blocks fixed.')
