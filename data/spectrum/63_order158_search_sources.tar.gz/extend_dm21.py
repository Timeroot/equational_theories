import json,time,subprocess
from pathlib import Path
from pysat.card import CardEnc,EncType
root=Path('/tmp/e63-158-20260924');d=json.loads(Path('data/spectrum/63_difference_matrices.json').read_text())['matrices']['21'];rows=[[x[0] for x in r] for r in d['rows']];n=21;clauses=[];top=n*n
v=lambda i,a:1+i*n+a
def exactly(vs):
 global top
 c=CardEnc.equals(vs,1,top_id=top,encoding=EncType.seqcounter);clauses.extend(c.clauses);top=c.nv
for i in range(n):exactly([v(i,a) for a in range(n)])
for j in range(6):
 for z in range(n):exactly([v(i,(z+rows[i][j])%n) for i in range(n)])
clauses.append([v(0,0)]);path=root/'extend-dm21.cnf';path.write_text(f'p cnf {top} {len(clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses));start=time.time();r=subprocess.run(['/usr/local/bin/cadical','-t','300',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=320);out=r.stdout.decode();(root/'extend-dm21.log').write_text(out);result={'status':'UNRESOLVED','seconds':time.time()-start}
if r.returncode==20:result['status']='UNSAT_FIXED_SIX_COLUMNS'
if r.returncode==10:
 vals={int(v) for l in out.splitlines() if l.startswith('v ') for v in l.split()[1:] if int(v)>0};col=[next(a for a in range(n) if v(i,a) in vals) for i in range(n)]
 for j in range(6):assert {(col[i]-rows[i][j])%n for i in range(n)}==set(range(n))
 result.update(status='VERIFIED_DM_EXTENSION',column=col)
(root/'extend-dm21.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
