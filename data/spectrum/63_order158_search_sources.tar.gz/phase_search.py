import sys,json,time
from pathlib import Path
from pysat.formula import CNF
from pysat.solvers import Solver
sys.path.insert(0,str(Path.cwd()/'scripts'))
from spectrum_63_bennett import prime,gf_affine,singular,product
root=Path('/tmp/e63-158-20260924');n,h=map(int,sys.argv[1:3]);start=time.time()
base=singular(prime(11),gf_affine(4,7,2,2),prime(3,False)) if n==34 else product(prime(5),prime(5))
assert len(base)==n
cnf=CNF(from_file=str(root/'nonidem'/f'hole-{n}-{h}.cnf'))
s=Solver(name='cadical195',bootstrap_with=cnf.clauses)
phases=[(1 if base[x][y]==z else -1)*(1+(x*n+y)*n+z) for x in range(n) for y in range(n) for z in range(n)]
s.set_phases(phases);print('loaded',n,h,len(cnf.clauses),flush=True);r=s.solve()
d={'order':n,'hole_size':h,'idempotent_outside':False,'status':'UNRESOLVED','seconds':time.time()-start,'method':'CaDiCaL with phases from an existing model'}
if r is False:d['status']='UNSAT_RESTRICTED_NO_CERTIFICATE'
if r:
 vals={x for x in s.get_model() if x>0};t=[[None if x<h and y<h else next(z for z in range(n) if 1+(x*n+y)*n+z in vals) for y in range(n)] for x in range(n)]
 for x in range(n):
  expected=set(range(h,n)) if x<h else set(range(n))
  assert {z for z in t[x] if z is not None}==expected
  assert {t[y][x] for y in range(n) if t[y][x] is not None}==expected
 for x in range(n):
  for y in range(n):
   if not(x<h and y<h):assert t[t[y][t[y][x]]][y]==x
 d.update(status='VERIFIED_PARTIAL_MODEL',table=t)
(root/f'phase-{n}-{h}.json').write_text(json.dumps(d,indent=2)+'\n');print(d['status'],flush=True)
