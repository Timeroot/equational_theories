#include <bits/stdc++.h>
using namespace std;using U=__uint128_t;
int h=23,hh=55,rep6[79],rep3[79],ci[79],cj[79],powh[3]={1,23,55};
uint16_t forbidA;uint32_t forbidCross;
vector<int> allowedA;long long shape_count=0,seeds=0;chrono::steady_clock::time_point deadline;
struct KeyHash{size_t operator()(U x)const{return (uint64_t)x^((uint64_t)(x>>64)*0x9e3779b97f4a7c15ULL);}};
U bit(int i){return U(1)<<i;}
int bd(int a,int b){return min((a-b+79)%79,(b-a+79)%79)-1;}
int cd(int a,int b){return 39+(a-b+79)%79;}
bool attempt(array<int,5>A,array<int,3>B,int a){
 ++seeds;U used=0;
 // B-special is {0}; A-special is {0,1,h,h^2}.
 for(int x:{0,1,h,hh})used|=bit(cd(x,0));
 for(int H:powh){
  for(int i=0;i<3;i++)for(int j=i+1;j<3;j++)used|=bit(bd(B[i]*H%79,B[j]*H%79));
  for(int x:A)for(int y:B)used|=bit(cd(x*H%79,y*H%79));
 }
 U rem=(bit(118)-1)^used;vector<int>opts;
 for(int x=0;x<79;x++)if((rem&bit(cd(0,x)))&&(rem&bit(cd(a,x))))opts.push_back(x);
 vector<array<int,5>> rows;vector<U>masks[3];array<int,5>C;
 function<void(int,int,U)> rec=[&](int pos,int start,U m){
  if(pos==5){
   rows.push_back(C);
   for(int H:powh){U z=0;for(int x:C){z|=bit(cd(0,x*H%79));z|=bit(cd(a*H%79,x*H%79));}for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)z|=bit(bd(C[i]*H%79,C[j]*H%79));masks[H==1?0:H==h?1:2].push_back(z);}return;
  }
  for(int i=start;i+(5-pos)<=int(opts.size());i++){
   int x=opts[i];U add=bit(cd(0,x))|bit(cd(a,x));if(m&add)continue;bool ok=true;
   for(int j=0;j<pos;j++){int d=bd(x,C[j]);if(d<0){ok=false;break;}U b=bit(d);if(!(rem&b)||((m|add)&b)){ok=false;break;}add|=b;}
   if(ok){C[pos]=x;rec(pos+1,i+1,m|add);}
  }
 };
 rec(0,0,0);unordered_map<U,int,KeyHash> lookup;
 for(int i=0;i<(int)rows.size();i++)lookup[masks[2][i]]=i;
 for(int i=0;i<(int)rows.size();i++)for(int j=0;j<(int)rows.size();j++){
  U m=masks[0][i],n=masks[1][j];if(m&n)continue;auto f=lookup.find(rem^(m|n));if(f==lookup.end())continue;
  ofstream out("/tmp/e63-158-20260924/relaxed-result.json");out<<"{\"status\":\"DESIGN_CANDIDATE\",\"a\":"<<a<<",\"blocks\":[[[0,0],[0,1],[0,23],[0,55],[1,0]]";
  int inds[3]={i,j,f->second};
  for(int t=0;t<3;t++){int H=powh[t];out<<",[[0,0],[0,"<<a*H%79<<"]";for(int x:rows[inds[t]])out<<",[1,"<<x*H%79<<"]";out<<"]";}
  for(int H:powh){out<<",[";bool first=true;for(int x:A){out<<(first?"":",")<<"[0,"<<x*H%79<<"]";first=false;}for(int y:B)out<<",[1,"<<y*H%79<<"]";out<<"]";}
  out<<"],\"shapes\":"<<shape_count<<",\"seeds\":"<<seeds<<"}\n";cerr<<"FOUND shapes "<<shape_count<<" seeds "<<seeds<<endl;return true;
 }
 return false;
}
int main(int argc,char**argv){
 deadline=chrono::steady_clock::now()+chrono::seconds(argc>1?atoi(argv[1]):600);
 vector<int>reps6,reps3;
 for(int d=1;d<79;d++){rep3[d]=min({d,d*h%79,d*hh%79});rep6[d]=min(rep3[d],min({79-d,79-d*h%79,79-d*hh%79}));reps6.push_back(rep6[d]);reps3.push_back(rep3[d]);}
 sort(reps6.begin(),reps6.end());reps6.erase(unique(reps6.begin(),reps6.end()),reps6.end());sort(reps3.begin(),reps3.end());reps3.erase(unique(reps3.begin(),reps3.end()),reps3.end());
 for(int d=1;d<79;d++){ci[d]=lower_bound(reps6.begin(),reps6.end(),rep6[d])-reps6.begin();cj[d]=lower_bound(reps3.begin(),reps3.end(),rep3[d])-reps3.begin();}
 int sp[4]={0,1,h,hh};for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)forbidA|=1<<ci[(sp[i]-sp[j]+79)%79];forbidCross=1<<cj[1];
 for(int x:reps6)if(!(forbidA>>ci[x]&1))allowedA.push_back(x);
 for(int first:{allowedA[0],allowedA[1]})for(int b=first+1;b<79;b++)for(int c=b+1;c<79;c++)for(int d=c+1;d<79;d++){
  array<int,5>A={0,first,b,c,d};uint16_t am=0;bool ok=true;
  for(int i=0;i<5&&ok;i++)for(int j=i+1;j<5;j++){uint16_t z=1<<ci[(A[i]-A[j]+79)%79];if((am|forbidA)&z){ok=false;break;}am|=z;}
  if(!ok)continue;int a=-1;for(int x:allowedA)if(!(am>>ci[x]&1))a=x;
  assert(a>0);if(first!=(a==allowedA[0]?allowedA[1]:allowedA[0]))continue;++shape_count;
  vector<pair<int,uint32_t>>opts;
  for(int x=0;x<79;x++){uint32_t mask=0;bool good=true;for(int y:A){int diff=(y-x+79)%79;if(!diff){good=false;break;}uint32_t z=1<<cj[diff];if((mask|forbidCross)&z){good=false;break;}mask|=z;}if(good)opts.push_back({x,mask});}
  for(int i=0;i<(int)opts.size();i++)for(int j=i+1;j<(int)opts.size();j++){
   if(opts[i].second&opts[j].second)continue;int dij=ci[(opts[i].first-opts[j].first+79)%79];
   for(int k=j+1;k<(int)opts.size();k++){
    if((opts[i].second|opts[j].second)&opts[k].second)continue;int dik=ci[(opts[i].first-opts[k].first+79)%79],djk=ci[(opts[j].first-opts[k].first+79)%79];if(dij==dik||dij==djk||dik==djk)continue;
    if(attempt(A,{opts[i].first,opts[j].first,opts[k].first},a))return 0;
   }
  }
  if(shape_count%25==0)cerr<<"shapes "<<shape_count<<" seeds "<<seeds<<endl;
  if(chrono::steady_clock::now()>deadline){cerr<<"TIMEOUT "<<shape_count<<" "<<seeds<<endl;return 0;}
 }
 cerr<<"EXHAUSTED "<<shape_count<<" "<<seeds<<endl;
}
