import json,time,random,itertools,collections
from pathlib import Path
from ortools.sat.python import cp_model
root=Path('/tmp/e63-158-20260924');H=[1,23,55]
def rep(d,t):return min([d*a%79 for a in H]+([] if t==2 else [-d*a%79 for a in H]))
reps={t:sorted({rep(d,t) for d in range(1,79)}) for t in [0,1,2]}
look={t:[52]+[(0 if t==0 else 13 if t==1 else 26)+reps[t].index(rep(d,t)) for d in range(1,79)] for t in [0,1,2]}
reserved={look[0][(a-b)%79] for a,b in itertools.combinations([0]+H,2)}|{look[2][1]}
edges=[]
for start,end,aa in [(0,7,2),(7,15,5)]:
 for a,b in itertools.combinations(range(start,end),2):edges.append((a,b,0 if b<start+aa else 1 if a>=start+aa else 2))
rng=random.Random(5849);start=time.time();outcomes=collections.Counter();attempt=0
while time.time()-start<600:
 data=json.loads((root/'symmetric-best.json').read_text());vals=data['positions'];keys=collections.defaultdict(list)
 for a,b,t in edges:keys[look[t][(vals[a]-vals[b])%79]].append({a,b}-{0,7})
 needed=[]
 for k,es in keys.items():
  if k in reserved or k==52:needed.extend(es)
  elif len(es)>1:needed.extend(rng.sample(es,len(es)-1))
 free=set()
 for es in needed:free.add(rng.choice(sorted(es)))
 sz=rng.choice([4,5,6,7,8,9]);free.update(rng.sample(sorted(set(range(15))-{0,7}-free),max(0,sz-len(free))))
 m=cp_model.CpModel();xs=[m.new_int_var(0,78,f'x{i}') if i in free else m.new_constant(v) for i,v in enumerate(vals)];ks=[]
 for a,b,t in edges:
  if a not in free and b not in free:k=m.new_constant(look[t][(vals[a]-vals[b])%79])
  else:
   d=m.new_int_var(1,78,f'd{a}_{b}');m.add_modulo_equality(d,xs[a]-xs[b]+79,79)
   dom=[v for v in look[t][1:] if v not in reserved];k=m.new_int_var_from_domain(cp_model.Domain.from_values(dom),f'k{a}_{b}');m.add_element(d,look[t],k)
  ks.append(k)
 m.add_all_different(ks)
 for i in free:m.add_hint(xs[i],vals[i])
 s=cp_model.CpSolver();s.parameters.max_time_in_seconds=3;s.parameters.num_search_workers=1;s.parameters.random_seed=rng.randrange(2**30)
 status=s.solve(m);attempt+=1;outcomes[s.status_name(status)]+=1
 if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
  result={'score':0,'positions':[s.value(x) for x in xs],'h':23,'attempt':attempt,'method':'CP-SAT local repair'};(root/'symmetric-repair-result.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True);break
 if attempt%10==0:print(attempt,dict(outcomes),time.time()-start,flush=True)
else:(root/'symmetric-repair-result.json').write_text(json.dumps({'status':'UNRESOLVED','attempts':attempt,'outcomes':dict(outcomes)},indent=2)+'\n')
