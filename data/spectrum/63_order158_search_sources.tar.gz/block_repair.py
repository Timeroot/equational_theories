import json,itertools,time,sys
from pathlib import Path
root=Path('/tmp/e63-158-20260924');seed=json.loads((root/'symmetric-best.json').read_text())['positions'];H=[1,23,55]
base=[[(0,x) for x in [0]+H]+[(1,0)]]
for xs,a in [(seed[:7],2),(seed[7:],5)]:
 for h in H:base.append([(int(i>=a),x*h%79) for i,x in enumerate(xs)])
def key(x,y):
 (s,a),(t,b)=x,y
 if s==t:return s*39+min((a-b)%79,(b-a)%79)-1 if a!=b else -1
 if s>t:a,b=b,a
 return 78+(a-b)%79
def mask(block):
 ks=[key(x,y) for x,y in itertools.combinations(block,2)]
 return None if -1 in ks or len(set(ks))!=len(ks) else sum(1<<k for k in ks)
start=time.time();count=0
for remove in itertools.combinations(range(1,7),int(sys.argv[1]) if len(sys.argv)>1 else 3):
 if sum(i<4 for i in remove)!=int(sys.argv[2] if len(sys.argv)>2 else 2):continue
 fixed=[b for i,b in enumerate(base) if i not in remove];used=0
 for b in fixed:
  m=mask(b)
  if m is None or m&used:break
  used|=m
 else:
  remaining=((1<<157)-1)^used;allowed=[{k for k in range(lo,hi) if remaining>>k&1} for lo,hi in [(0,39),(39,78),(78,157)]]
  cand={};needed={7:sum(i<4 for i in remove),8:sum(i>=4 for i in remove)}
  for size,asize in [(7,2),(8,5)]:
   if not needed[size]:continue
   rows={};bsize=size-asize
   def build_b(A,B,opts,m):
    if len(B)==bsize:
     rows[m]=[(0,a) for a in A]+[(1,b) for b in B];return
    for i,x in enumerate(opts):
     if len(opts)-i < bsize-len(B):break
     add=0;ok=True
     for a in A:
      k=key((0,a),(1,x));bit=1<<k
      if (m|add)&bit:ok=False;break
      add|=bit
     if not ok:continue
     for b in B:
      k=key((1,x),(1,b))
      if k not in allowed[1] or (m|add)>>k&1:ok=False;break
      add|=1<<k
     if ok:build_b(A,B+[x],opts[i+1:],m|add)
   def build_a(A,opts,bopts,m):
    if len(A)==asize:
     # Normalize a closest pair to 0,A[1], retaining one representative per translation orbit.
     if A[1]!=min(key((0,a),(0,b))+1 for a,b in itertools.combinations(A,2)):return
     build_b(A,[],bopts,m);return
    for i,x in enumerate(opts):
     if len(opts)-i < asize-len(A):break
     add=0;ok=True
     for a in A:
      k=key((0,x),(0,a))
      if k not in allowed[0] or (m|add)>>k&1:ok=False;break
      add|=1<<k
     if not ok:continue
     newb=[b for b in bopts if key((0,x),(1,b)) in allowed[2]]
     if len(newb)>=bsize:build_a(A+[x],opts[i+1:],newb,m|add)
   build_a([0],[x for x in range(1,79) if key((0,0),(0,x)) in allowed[0]],[x for x in range(79) if key((0,0),(1,x)) in allowed[2]],0)
   cand[size]=rows;print('remove',remove,'size',size,'candidates',len(rows),'seconds',time.time()-start,flush=True)
  bykey={}
  for size,rows in cand.items():
   bykey[size]={}
   for m,b in rows.items():
    bits=m
    while bits:
     bit=bits&-bits;bits-=bit;bykey[size].setdefault(bit,[]).append((m,b))
  def cover(left,need,chosen):
   global count
   count+=1
   if not left:return chosen
   if time.time()-start>900:raise TimeoutError
   opts=None;bits=left
   while bits:
    bit=bits&-bits;bits-=bit
    choices=[(s,m,b) for s in [7,8] if need.get(s,0) for m,b in bykey[s].get(bit,[]) if m&left==m]
    if not choices:return None
    if opts is None or len(choices)<len(opts):opts=choices
   for s,m,b in opts:
    newneed=dict(need);newneed[s]-=1;r=cover(left^m,newneed,chosen+[b])
    if r is not None:return r
   return None
  r=cover(remaining,needed,[])
  if r is not None:
   result={'status':'DESIGN_CANDIDATE','method':'exact block repair','removed':remove,'blocks':fixed+r}
   (root/'block-repair-result.json').write_text(json.dumps(result,indent=2)+'\n');print('FOUND',flush=True);break
  print('No exact cover for',remove,flush=True)
else:print('All selected block repairs exhausted',time.time()-start,count,flush=True)
