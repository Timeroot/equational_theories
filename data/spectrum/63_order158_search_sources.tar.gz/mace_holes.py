import subprocess,json,time,sys,re
from pathlib import Path
root=Path('/tmp/e63-158-20260924');n,h=map(int,sys.argv[1:3]);guard=f'(x < {h} & y < {h})';defined=f'-(x < {h} & y < {h})'
source=f'''set(integer_ring).
set(order_domain).
formulas(assumptions).
(x < {h} & y < {h}) -> mul(x,y) = 0.
(x < {h} & -(y < {h})) -> -(mul(x,y) < {h}).
(y < {h} & -(x < {h})) -> -(mul(x,y) < {h}).
(x < {h} & y < {h}) | (x < {h} & z < {h}) | mul(x,y) != mul(x,z) | y = z.
(x < {h} & y < {h}) | (x < {h} & z < {h}) | mul(y,x) != mul(z,x) | y = z.
{guard} | mul(mul(y,mul(y,x)),y) = x.
{guard} | mul(y,mul(y,mul(x,y))) = x.
{guard} | mul(y,mul(mul(y,x),y)) = x.
end_of_list.
'''
path=root/f'mace-hole-{n}-{h}.in';path.write_text(source);start=time.time()
try:
 r=subprocess.run(['/tmp/e63-prover9/bin/mace4','-n',str(n),'-N',str(n),'-t','600','-b','2048','-f',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=620);out=r.stdout.decode();(root/f'mace-hole-{n}-{h}.log').write_text(out)
 d={'order':n,'hole_size':h,'seconds':time.time()-start,'exit_code':r.returncode,'status':'UNRESOLVED'}
 match=re.search(r'function\(mul\(_, _\),\s*\[([^]]+)\]',out)
 if not match:match=re.search(r'function\(mul\(_,_\),\s*\[([^]]+)\]',out)
 if match:
  vs=[int(v) for v in re.findall(r'\d+',match[1])];assert len(vs)==n*n;t=[[None if x<h and y<h else vs[x*n+y] for y in range(n)] for x in range(n)]
  for x in range(n):
   want=set(range(h,n)) if x<h else set(range(n))
   assert {v for v in t[x] if v is not None}==want
   assert {t[y][x] for y in range(n) if t[y][x] is not None}==want
  for x in range(n):
   for y in range(n):
    if not(x<h and y<h):assert t[t[y][t[y][x]]][y]==x
  d.update(status='VERIFIED_PARTIAL_MODEL',table=t)
except subprocess.TimeoutExpired as e:
 (root/f'mace-hole-{n}-{h}.log').write_bytes(e.stdout or b'');d={'order':n,'hole_size':h,'status':'UNRESOLVED','seconds':time.time()-start}
(root/f'mace-hole-{n}-{h}.json').write_text(json.dumps(d,indent=2)+'\n');print(d['status'],flush=True)
