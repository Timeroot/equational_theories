import json,gzip,time,random,subprocess,concurrent.futures,itertools
from pathlib import Path
root=Path('/tmp/e63-158-20260924');n=23;owner=[i//3 for i in range(21)]+[7,7];lines=(root/'pils-3-3-3-3-3-3-3-2.cnf').read_text().splitlines();head=lines[0].split();body='\n'.join(lines[1:])+'\n';var=lambda x,y,z:1+(x*n+y)*n+z
def parts(n,m=3):
 if n==0:yield []
 for k in range(m,n+1):
  for r in parts(n-k,k):yield [k]+r
rng=random.Random(791583);cases=[]
for cs in parts(21):
 for repeat in range(2):
  for trial in range(10000):
   xs=list(range(21));rng.shuffle(xs);perm={};p=0
   for k in cs:
    for i in range(k):perm[xs[p+i]]=xs[p+(i+1)%k]
    p+=k
   if all(owner[x]!=owner[perm[x]] and owner[x]!=owner[perm[perm[x]]] for x in range(21)):break
  else:continue
  cases.append({'cycles':cs,'permutation':[perm[x] for x in range(21)]})
(root/'pils-one-root-cases.json').write_text(json.dumps(cases,indent=2)+'\n');print('cases',len(cases),flush=True)
def run(item):
 index,c=item;name=f'pils-one-root-{index}';perm=c['permutation'];inv={y:x for x,y in enumerate(perm)};extra=[]
 for x in range(21):extra.extend([[var(21,x,perm[x])],[var(x,21,inv[inv[x]])]])
 path=root/(name+'.cnf.gz');path.write_bytes(gzip.compress((f'p cnf {head[2]} {int(head[3])+len(extra)}\n'+body+''.join(' '.join(map(str,k))+' 0\n' for k in extra)).encode(),compresslevel=1));start=time.time()
 r=subprocess.run(['/usr/local/bin/cadical','-t','10',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20);out=r.stdout.decode();(root/(name+'.log')).write_text(out);d={'sizes':[3]*7+[2],**c,'status':'UNRESOLVED','seconds':time.time()-start}
 if r.returncode==20:d['status']='UNSAT_RESTRICTED_NO_CERTIFICATE'
 if r.returncode==10:
  vals={int(v) for l in out.splitlines() if l.startswith('v ') for v in l.split()[1:] if int(v)>0};t=[[None if owner[x]==owner[y] else next(z for z in range(n) if var(x,y,z) in vals) for y in range(n)] for x in range(n)]
  for x in range(n):
   expected={z for z in range(n) if owner[z]!=owner[x]};assert {z for z in t[x] if z is not None}==expected;assert {t[y][x] for y in range(n) if t[y][x] is not None}==expected
  for x,y in itertools.product(range(n),repeat=2):
   if owner[x]!=owner[y]:assert t[t[y][t[y][x]]][y]==x
  d.update(status='VERIFIED_PARTIAL_MODEL',table=t)
 p=root/(name+'.json');p.write_text(json.dumps(d,indent=2)+'\n')
 if r.returncode==10:subprocess.run(['python3',str(root/'assemble_partial.py'),str(p)],check=True)
 print(index,c['cycles'],d['status'],round(d['seconds'],2),flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:res=list(p.map(run,enumerate(cases)))
(root/'pils-one-root-report.json').write_text(json.dumps(res,indent=2)+'\n')
