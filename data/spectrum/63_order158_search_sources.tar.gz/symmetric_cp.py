import json,time
from pathlib import Path
from ortools.sat.python import cp_model
P=79;h=next(x for x in range(2,P) if pow(x,3,P)==1);H=[1,h,h*h%P]
rep=lambda d,t:min([d*a%P for a in H]+([] if t else [-d*a%P for a in H]))
reps=[sorted({rep(d,t) for d in range(1,P)}) for t in [0,1]]
lookup=[[52]+[reps[t].index(rep(d,t))+(26 if t else 0) for d in range(1,P)] for t in [0,1]]
sp=[0]+H
reserved={lookup[0][(a-b)%P] for i,a in enumerate(sp) for b in sp[i+1:]};reserved.add(lookup[1][1]);assert len(reserved)==3
m=cp_model.CpModel();x=[m.new_int_var(0,78,f'x{i}') for i in range(15)]
m.add(x[0]==0);m.add(x[7]==0)
allowed=[d for d in reps[0] if lookup[0][d] not in reserved]
m.add_allowed_assignments([x[1]],[(a,) for a in allowed])
# Any pair of the 8-block's five points in orbit A can be moved to 0,a;
# choose the pair with the smallest +/-H difference, which is determined by x[1].
m.add_allowed_assignments([x[1],x[8]],[(a,min(d for d in allowed if d!=a)) for a in allowed])
for inds in [range(2,7),range(7,12),range(12,15)]:
 for a,b in zip(inds,list(inds)[1:]):m.add(x[a]<x[b])
ks=[]
for start,end,aa in [(0,7,2),(7,15,5)]:
 for a in range(start,end):
  for b in range(a+1,end):
   t=0 if b<start+aa else 1 if a>=start+aa else 2
   d=m.new_int_var(1,78,f'd{a}_{b}');m.add_modulo_equality(d,x[a]-x[b]+79,79)
   permitted=[v for v in range(52) if v not in reserved and (v<13 if t==0 else 13<=v<26 if t==1 else v>=26)]
   k=m.new_int_var_from_domain(cp_model.Domain.from_values(permitted),f'k{a}_{b}')
   vals=lookup[1] if t==2 else [v+13*t if v!=52 else 52 for v in lookup[0]]
   m.add_element(d,vals,k);ks.append(k)
m.add_all_different(ks)
s=cp_model.CpSolver();s.parameters.max_time_in_seconds=600;s.parameters.num_search_workers=8;s.parameters.log_search_progress=True
status=s.solve(m);out={'status':s.status_name(status),'h':h,'seconds':s.wall_time,'scope':'restricted multiplicative-order3 cyclic PBD construction only'}
if status in [cp_model.OPTIMAL,cp_model.FEASIBLE]:out['positions']=[s.value(z) for z in x];out['score']=0
Path('/tmp/e63-158-20260924/symmetric-cp-result.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
