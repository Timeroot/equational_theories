import concurrent.futures,itertools,json,time
from pathlib import Path
from split_search import search
DEST=Path('.cache/e1483-fo')
def complete(case):
 p=DEST/('split_'+str(case[0])+'_'+''.join(map(str,case[1]))+'.json')
 try: return json.loads(p.read_text())['status'] in ['unsat','sat']
 except (ValueError,OSError): return False
def run(case):
 rank,prefix,seconds=case;start=time.monotonic()
 status,table=search(12,rank,seconds,normalize_first_row=True,prefix=prefix)
 ans=dict(order=12,minimum_rank=rank,first_row_prefix=prefix,budget_seconds=seconds,
  elapsed_seconds=round(time.monotonic()-start,3),status=status,table=table,
  trust='exploratory solver result, not a Lean refutation')
 (DEST/('split_'+str(rank)+'_'+''.join(map(str,prefix))+'.json')).write_text(json.dumps(ans,indent=2)+'\n')
 return ans
if __name__=='__main__':
 cases=[(3,(1,b,c,d),300) for b,c,d in itertools.product(range(1,3),range(1,4),range(1,4))]
 cases += [(4,(a,b),600) for a,b in itertools.product(range(2),range(3))]
 cases=[case for case in cases if not complete(case)]
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
  for result in pool.map(run,cases):print(json.dumps(result),flush=True)
