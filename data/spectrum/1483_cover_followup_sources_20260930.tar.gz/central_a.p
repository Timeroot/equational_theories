fof(central,axiom, ![X,Y,Z] : f(f(Y,X),f(X,Z)) = X).
fof(cancel1,axiom, ![X,Y,Z] : b(f(Y,X),f(X,f(Y,Z))) = a(Y,X)).
fof(cancel2,axiom, ![X,Y,Z] : a(f(Y,X),f(X,f(Y,Z))) = b(X,f(Y,Z))).
fof(goal,conjecture, ![X,Y,Z] : b(f(Y,X),f(X,Z)) = a(Y,X)).
