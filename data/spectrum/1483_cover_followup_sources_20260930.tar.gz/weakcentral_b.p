fof(law1483,axiom, ![X,Y,Z] : f(f(Y,X),f(X,f(Y,Z))) = X).
fof(law1485,axiom, ![X,Y,Z] : f(f(Y,X),f(X,f(Z,Y))) = X).
fof(cancel1,axiom, ![X,Y,Z] : b(f(Y,X),f(X,f(Y,Z))) = a(Y,X)).
fof(cancel2,axiom, ![X,Y,Z] : a(f(Y,X),f(X,f(Y,Z))) = b(X,f(Y,Z))).
fof(goal,conjecture, ![X,Y,Z] : a(f(Y,X),f(X,f(Z,Y))) = b(X,f(Z,Y))).
