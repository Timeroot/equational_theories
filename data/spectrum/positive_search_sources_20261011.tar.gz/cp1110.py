import json,sys,time
from pathlib import Path
sys.modules["pyarrow"] = None
from ortools.sat.python import cp_model
sys.path.insert(0,'scripts')
from spectrum_generate import load_equations,satisfies
n=int(sys.argv[1]);auto=bool(int(sys.argv[2]));budget=int(sys.argv[3]);out=Path(sys.argv[4]);r=range(n)
m=cp_model.CpModel();p=[[m.NewIntVar(0,n-1,f'p{x}_{y}') for y in r] for x in r];flat=sum(p,[]);D=[p[x][x] for x in r]
for x in r:
 m.AddAllDifferent(p[x]);m.AddAllDifferent([p[y][x] for y in r])
 m.Add(p[0][x]<=x+1)
m.AddAllDifferent(D);m.Add(p[0][0]==1)
for x in r:
 d2=m.NewIntVar(0,n-1,f'd2{x}');m.AddElement(D[x],D,d2)
 fixed=m.NewBoolVar(f'fixed{x}');m.Add(D[x]==x).OnlyEnforceIf(fixed);m.Add(D[x]!=x).OnlyEnforceIf(fixed.Not());m.Add(d2!=x).OnlyEnforceIf(fixed.Not())
for y in r:
 inv=[m.NewIntVar(0,n-1,f'inv{y}_{x}') for x in r];m.AddInverse(p[y],inv)
 for x in r:
  a=m.NewIntVar(0,n-1,f'a{x}_{y}');m.AddElement(D[x],p[y],a);m.AddElement(a,[p[z][y] for z in r],inv[x])
  if auto:
   idx=m.NewIntVar(0,n*n-1,f'idx{x}_{y}');m.Add(idx==n*D[x]+D[y]);t=m.NewIntVar(0,n-1,f'aut{x}_{y}');m.AddElement(idx,flat,t);m.AddElement(p[x][y],D,t)
s=cp_model.CpSolver();s.parameters.max_time_in_seconds=budget;s.parameters.num_search_workers=4;s.parameters.random_seed=7
start=time.monotonic();status=s.Solve(m)
record=dict(law=1110,order=n,family='square-automorphism' if auto else 'nonidempotent; square no two-cycles',solver='CP-SAT',status=s.StatusName(status),seconds=time.monotonic()-start,budget=budget,table=None,statistics=s.ResponseStats())
if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
 table=[[s.Value(p[x][y]) for y in r] for x in r];assert satisfies(*load_equations()[1110-1],sum(table,[]),n);record['table']=table
out.write_text(json.dumps(record,indent=2)+'\n');print(record['status'],record['seconds'],flush=True)
