import sys,time,json,subprocess,concurrent.futures
from pathlib import Path
sys.path.insert(0,'scripts')
from spectrum_small_orders import clauses,variables
root=Path('.cache/spectrum-positive-20261011/diagonal12');n=12;p=lambda x,y,z:1+(x*n+y)*n+z
oldchain={-p(0,y,z) for y in range(n) for z in range(y+2,n)}
base=[c for c in clauses(1110,n) if not (len(c)==1 and c[0] in oldchain)]
def parts(n,lo=1):
 if not n:yield[]
 for k in range(lo,n+1):
  if k!=2:
   for a in parts(n-k,k):yield[k]+a
def run(ps):
 ps=sorted(ps,key=lambda x:(x==1,x));name='cycles_'+ '_'.join(map(str,ps));d=[]
 for k in ps:
  o=len(d);d.extend(list(range(o+1,o+k))+[o])
 cs=base+[[p(x,x,y)] for x,y in enumerate(d)]
 (root/(name+'.cnf')).write_text(f'p cnf {variables(1110,n)} {len(cs)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in cs))
 t=time.monotonic()
 with (root/(name+'.log')).open('w') as f:r=subprocess.run(['cadical','-t','30',str(root/(name+'.cnf'))],stdout=f,stderr=subprocess.STDOUT)
 rec={'cycles':ps,'diagonal':d,'status':{10:'SAT',20:'UNSAT'}.get(r.returncode,'UNKNOWN'),'seconds':round(time.monotonic()-t,3)}
 (root/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
 return rec
ps=[a for a in parts(n) if a!=[1]*n]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:result=list(ex.map(run,reversed(ps)))
(root/'cycle_sweep.json').write_text(json.dumps(result,indent=2)+'\n')
