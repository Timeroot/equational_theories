import sys,json,subprocess,time,hashlib
from pathlib import Path
from itertools import product,combinations
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'scripts')
from spectrum_small_pair_search import encode,loop_cases
from spectrum_generate import satisfies,load_equations
n=12;r=range(n);top,base=encode(1110,n,right=True,normalize=False)
p=lambda x,y,z:1+(x*n+y)*n+z

def run(name,table,group):
 cs=list(base);a=lambda x,z:top+1+x*n+z;b=lambda x,z:top+1+n*n+x*n+z
 for i in r:
  for fun in (a,b):
   for vs in ([fun(i,z) for z in r],[fun(z,i) for z in r]):
    cs.append(vs);cs.extend([-u,-v] for u,v in combinations(vs,2))
 if group:cs.append([a(0,0)])
 for x,y,u,v in product(r,repeat=4):cs.append([-a(x,u),-b(y,v),p(x,y,table[u][v])])
 path=Path('.cache/spectrum-positive-20261011')/('E1110N12-isotope-'+name)
 data=(f'p cnf {top+2*n*n} {len(cs)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in cs)).encode();path.with_suffix('.cnf').write_bytes(data)
 command=['cadical','-t','300',str(path.with_suffix('.cnf'))];start=time.monotonic();proc=subprocess.run(command,capture_output=True,text=True,timeout=330)
 path.with_suffix('.log').write_text(proc.stdout+proc.stderr)
 rec=dict(law=1110,order=n,family='principal isotopes of '+name,group=group,budget=300,seconds=time.monotonic()-start,status={10:'SAT',20:'UNSAT'}.get(proc.returncode,'UNKNOWN'),command=command,cnf_sha256=hashlib.sha256(data).hexdigest(),table=None)
 if proc.returncode==10:
  vals={int(v) for l in proc.stdout.splitlines() if l.startswith('v ') for v in l.split()[1:]}
  model=[[next(z for z in r if p(x,y,z) in vals) for y in r] for x in r];assert satisfies(*load_equations()[1109],sum(model,[]),n);rec['table']=model
 path.with_suffix('.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['status'],round(rec['seconds'],2),flush=True)
with ThreadPoolExecutor(max_workers=6) as pool:
 fs=[pool.submit(run,name,t,g) for law,name,t,g in loop_cases() if len(t)==12]
 for f in fs:f.result()
